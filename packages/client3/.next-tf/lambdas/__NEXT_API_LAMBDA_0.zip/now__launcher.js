"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
// The Next.js builder can emit the project in a subdirectory depending on how
// many folder levels of `node_modules` are traced. To ensure `process.cwd()`
// returns the proper path, we change the directory to the folder with the
// launcher. This mimics `yarn workspace run` behavior.
process.chdir(__dirname);
if (!process.env.NODE_ENV) {
    const region = process.env.VERCEL_REGION || process.env.NOW_REGION;
    process.env.NODE_ENV = region === 'dev1' ? 'development' : 'production';
}
const http_1 = require("http");
const now__bridge_1 = require("./now__bridge");
// eslint-disable-next-line
let page = {};

              const url = require('url');

              function stripLocalePath(pathname) { return pathname }

              page = function(req, res) {
                try {
                  const pages = {
                    '/api/gfi-grants': () => require('./.next/serverless/pages/api/gfi-grants.js'),
'/api/hello': () => require('./.next/serverless/pages/api/hello.js'),
'/api/pool': () => require('./.next/serverless/pages/api/pool.js'),
'/api/pool/[poolId]': () => require('./.next/serverless/pages/api/pool/[poolId].js')
                    
                  }
                  let toRender = req.headers['x-nextjs-page']

                  if (!toRender) {
                    try {
                      const { pathname } = url.parse(req.url)
                      toRender = stripLocalePath(pathname).replace(/\/$/, '') || '/index'
                    } catch (_) {
                      // handle failing to parse url
                      res.statusCode = 400
                      return res.end('Bad Request')
                    }
                  }

                  let currentPage = pages[toRender]

                  if (
                    toRender &&
                    !currentPage
                  ) {
                    if (toRender.includes('/_next/data')) {
                      toRender = toRender
                        .replace(new RegExp('/_next/data/U\-HHRESVH\-J1Unnx7pI4N/'), '/')
                        .replace(/\.json$/, '')

                      toRender = stripLocalePath(toRender) || '/index'
                      currentPage = pages[toRender]
                    }

                    if (!currentPage) {
                      // for prerendered dynamic routes (/blog/post-1) we need to
                      // find the match since it won't match the page directly
                      const dynamicRoutes = [{"src":"^/api/pool/(?<poolId>[^/]+?)(?:/)?$","dest":"/api/pool/[poolId]?poolId=$poolId"},{"src":"^/artist/pool/(?<address>[^/]+?)(?:/)?$","dest":"/artist/pool/[address]?address=$address"},{"src":"^/backer/pool/(?<address>[^/]+?)(?:/)?$","dest":"/backer/pool/[address]?address=$address"},{"src":"^/(?<role>[^/]+?)/transactions(?:/)?$","dest":"/[role]/transactions?role=$role"}]

                      for (const route of dynamicRoutes) {
                        const matcher = new RegExp(route.src)

                        if (matcher.test(toRender)) {
                          toRender = url.parse(route.dest).pathname
                          currentPage = pages[toRender]
                          break
                        }
                      }
                    }
                  }

                  if (!currentPage) {
                    console.error(
                      "Failed to find matching page for", {toRender, header: req.headers['x-nextjs-page'], url: req.url }, "in lambda"
                    )
                    console.error('pages in lambda', Object.keys(pages))
                    res.statusCode = 500
                    return res.end('internal server error')
                  }

                  const mod = currentPage()
                  const method = mod.render || mod.default || mod

                  return method(req, res)
                } catch (err) {
                  console.error('Unhandled error during request:', err)
                  throw err
                }
              }
              
// page.render is for React rendering
// page.default is for /api rendering
// page is for module.exports in /api
const server = new http_1.Server(page.render || page.default || page);
const bridge = new now__bridge_1.Bridge(server);
bridge.listen();
exports.launcher = bridge.launcher;
