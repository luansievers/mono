"use strict";
exports.id = 93;
exports.ids = [93];
exports.modules = {

/***/ 5093:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "f": () => (/* binding */ PendingPoolCard)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8103);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(clsx__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _hooks_user_hooks__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4569);
/* harmony import */ var _lib_format_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1441);
/* harmony import */ var _lib_graphql_generated__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2190);
/* harmony import */ var _design_system__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1490);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_hooks_user_hooks__WEBPACK_IMPORTED_MODULE_2__, _design_system__WEBPACK_IMPORTED_MODULE_4__]);
([_hooks_user_hooks__WEBPACK_IMPORTED_MODULE_2__, _design_system__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);






function PendingPoolCard({ image , artistName , poolName , statusType , className , onClick , onButtonClick  }) {
    const isAdmin = (0,_hooks_user_hooks__WEBPACK_IMPORTED_MODULE_2__/* .useAdmin */ .Aj)();
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: clsx__WEBPACK_IMPORTED_MODULE_1___default()("flex gap-4 rounded-lg bg-green-100 px-6 py-4", onClick && "cursor-pointer", className),
        onClick: onClick,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "flex-none",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_design_system__WEBPACK_IMPORTED_MODULE_4__/* .Avatar */ .qE, {
                    size: 20,
                    image: image
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex-1 pt-[18.5px]",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_design_system__WEBPACK_IMPORTED_MODULE_4__/* .BodyText */ .Ac, {
                        size: "normal",
                        className: "text-light-40",
                        children: (artistName === null || artistName === void 0 ? void 0 : artistName.startsWith("0x")) ? (0,_lib_format_common__WEBPACK_IMPORTED_MODULE_5__/* .handleAddressFormat */ .p)(artistName) : artistName
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_design_system__WEBPACK_IMPORTED_MODULE_4__/* .Caption */ .YS, {
                        className: "pt-[3px] text-dark-50",
                        children: poolName
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "flex-1 pt-[28px] text-center capitalize",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_design_system__WEBPACK_IMPORTED_MODULE_4__/* .Chip */ .Af, {
                        type: statusType == _lib_graphql_generated__WEBPACK_IMPORTED_MODULE_3__/* .Pool_Status_Type.InReview */ .k$.InReview ? "pending" : _lib_graphql_generated__WEBPACK_IMPORTED_MODULE_3__/* .Pool_Status_Type.Approved */ .k$.Approved ? "completed" : "failed",
                        children: statusType == _lib_graphql_generated__WEBPACK_IMPORTED_MODULE_3__/* .Pool_Status_Type.ReviewFailed */ .k$.ReviewFailed ? "failed" : statusType == _lib_graphql_generated__WEBPACK_IMPORTED_MODULE_3__/* .Pool_Status_Type.InReview */ .k$.InReview ? "pending" : "approved"
                    })
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex justify-between pt-[20px]",
                children: [
                    isAdmin && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_design_system__WEBPACK_IMPORTED_MODULE_4__/* .Button */ .zx, {
                        onClick: (event)=>{
                            onButtonClick && onButtonClick(event, false);
                        },
                        className: "mr-[10px]",
                        buttonType: "secondary",
                        children: "Decline"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_design_system__WEBPACK_IMPORTED_MODULE_4__/* .Button */ .zx, {
                        onClick: (event)=>{
                            onButtonClick && onButtonClick(event, true);
                        },
                        disabled: statusType == _lib_graphql_generated__WEBPACK_IMPORTED_MODULE_3__/* .Pool_Status_Type.InReview */ .k$.InReview && !isAdmin,
                        children: isAdmin ? "Approve" : "Launch Pool"
                    })
                ]
            })
        ]
    }));
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;