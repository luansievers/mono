"use strict";
exports.id = 800;
exports.ids = [800];
exports.modules = {

/***/ 2800:
/***/ ((module) => {

module.exports = {"Dg":[]};

/***/ })

};
;