"use strict";
exports.id = 421;
exports.ids = [421];
exports.modules = {

/***/ 3421:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8103);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(clsx__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _design_system__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1490);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_design_system__WEBPACK_IMPORTED_MODULE_3__]);
_design_system__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




function UploadPDF({ className , uploadedFile , onFileUpload , onRemoveFile  }) {
    const hiddenFileInput = (0,react__WEBPACK_IMPORTED_MODULE_2__.useRef)(null);
    const handleClick = (event)=>{
        var ref;
        event.preventDefault();
        hiddenFileInput === null || hiddenFileInput === void 0 ? void 0 : (ref = hiddenFileInput.current) === null || ref === void 0 ? void 0 : ref.click();
    };
    const handleChange = (event)=>{
        var ref, ref1;
        if ((ref = event.target) === null || ref === void 0 ? void 0 : (ref1 = ref.files) === null || ref1 === void 0 ? void 0 : ref1[0]) {
            const chosenFile = event.target.files[0];
            onFileUpload && onFileUpload(chosenFile);
        }
    };
    if (uploadedFile) {
        return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_design_system__WEBPACK_IMPORTED_MODULE_3__/* .BodyText */ .Ac, {
            size: "small",
            semiBold: true,
            className: clsx__WEBPACK_IMPORTED_MODULE_1___default()("flex flex-row items-center text-light-40", className),
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_design_system__WEBPACK_IMPORTED_MODULE_3__/* .Icon */ .JO, {
                    name: "ClipboardText",
                    size: "lg"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_design_system__WEBPACK_IMPORTED_MODULE_3__/* .Link */ .rU, {
                    className: "ml-3",
                    href: "#",
                    noUnderline: true,
                    children: uploadedFile.fileName
                }),
                onRemoveFile ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    className: "cursor-pointer",
                    onClick: ()=>{
                        onRemoveFile();
                    },
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_design_system__WEBPACK_IMPORTED_MODULE_3__/* .Icon */ .JO, {
                        className: "ml-3 stroke-dark-50",
                        name: "XCircle",
                        size: "lg"
                    })
                }) : null
            ]
        }));
    }
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: clsx__WEBPACK_IMPORTED_MODULE_1___default()("flex flex-row items-center", className),
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_design_system__WEBPACK_IMPORTED_MODULE_3__/* .Button */ .zx, {
                buttonType: "custom",
                className: clsx__WEBPACK_IMPORTED_MODULE_1___default()("rounded-[6px] border border-dark-80 bg-transparent text-light-10 hover:bg-dark-90 disabled:border-dark-80 disabled:text-dark-80 disabled:hover:bg-white"),
                childrenClassName: "py-2",
                onClick: handleClick,
                children: "Choose File"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                type: "file",
                ref: hiddenFileInput,
                onChange: handleChange,
                className: "hidden",
                accept: "application/pdf"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_design_system__WEBPACK_IMPORTED_MODULE_3__/* .Caption */ .YS, {
                className: "ml-4 text-dark-50",
                children: " No File chosen"
            })
        ]
    }));
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (UploadPDF);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;