"use strict";
exports.id = 209;
exports.ids = [209];
exports.modules = {

/***/ 2209:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "gq": () => (/* binding */ DirectGrantSource),
/* harmony export */   "eR": () => (/* binding */ IndirectGrantSource),
/* harmony export */   "k$": () => (/* binding */ Pool_Status_Type)
/* harmony export */ });
/* unused harmony exports BackerRewardsData_OrderBy, CommunityRewardsTokenSource, CommunityRewardsToken_OrderBy, CreditLine_OrderBy, GrantReason, JuniorTrancheInfo_OrderBy, OrderDirection, SeniorPoolStakedPosition_OrderBy, SeniorPoolStatus_OrderBy, SeniorPool_OrderBy, SeniorTrancheInfo_OrderBy, StakedPositionType, StakingRewardsData_OrderBy, SupportedCrypto, SupportedFiat, TranchedPoolCreditLineVersion, TranchedPoolToken_OrderBy, TranchedPool_OrderBy, TransactionCategory, Transaction_OrderBy, UidType, User_OrderBy, Zap_OrderBy, _SubgraphErrorPolicy_, TranchedPoolStatusFieldsFragmentDoc, UserEligibilityFieldsFragmentDoc, CurrentUserWalletInfoDocument, useCurrentUserWalletInfoQuery, useCurrentUserWalletInfoLazyQuery, StatusCheckStepDocument, useStatusCheckStepQuery, useStatusCheckStepLazyQuery, CurrentUserTransactionsDocument, useCurrentUserTransactionsQuery, useCurrentUserTransactionsLazyQuery, AllPendingPoolsDocument, useAllPendingPoolsQuery, useAllPendingPoolsLazyQuery, ArtistGetAllPoolsGraphDataDocument, useArtistGetAllPoolsGraphDataQuery, useArtistGetAllPoolsGraphDataLazyQuery, ArtistPoolMetadataListDocument, useArtistPoolMetadataListQuery, useArtistPoolMetadataListLazyQuery, PendingPoolsDocument, usePendingPoolsQuery, usePendingPoolsLazyQuery, ArtistPoolMetadataDocument, useArtistPoolMetadataQuery, useArtistPoolMetadataLazyQuery, ArtistPoolGraphDataDocument, useArtistPoolGraphDataQuery, useArtistPoolGraphDataLazyQuery, BackerGetAllPoolsGraphDataDocument, useBackerGetAllPoolsGraphDataQuery, useBackerGetAllPoolsGraphDataLazyQuery, BackerPoolAddressPoolMetadataDocument, useBackerPoolAddressPoolMetadataQuery, useBackerPoolAddressPoolMetadataLazyQuery, BackerPoolMetadataDocument, useBackerPoolMetadataQuery, useBackerPoolMetadataLazyQuery, BackerPoolGraphDataDocument, useBackerPoolGraphDataQuery, useBackerPoolGraphDataLazyQuery */
/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9114);
/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_apollo_client__WEBPACK_IMPORTED_MODULE_0__);


const defaultOptions = {};
var BackerRewardsData_OrderBy;
(function(BackerRewardsData_OrderBy) {
    BackerRewardsData_OrderBy["ContractAddress"] = 'contractAddress';
    BackerRewardsData_OrderBy["Id"] = 'id';
    BackerRewardsData_OrderBy["MaxInterestDollarsEligible"] = 'maxInterestDollarsEligible';
    BackerRewardsData_OrderBy["TotalRewardPercentOfTotalGfi"] = 'totalRewardPercentOfTotalGFI';
    BackerRewardsData_OrderBy["TotalRewards"] = 'totalRewards';
})(BackerRewardsData_OrderBy || (BackerRewardsData_OrderBy = {}));
var CommunityRewardsTokenSource;
(function(CommunityRewardsTokenSource) {
    CommunityRewardsTokenSource["BackerMerkleDistributor"] = 'BACKER_MERKLE_DISTRIBUTOR';
    CommunityRewardsTokenSource["MerkleDistributor"] = 'MERKLE_DISTRIBUTOR';
})(CommunityRewardsTokenSource || (CommunityRewardsTokenSource = {}));
var CommunityRewardsToken_OrderBy;
(function(CommunityRewardsToken_OrderBy) {
    CommunityRewardsToken_OrderBy["CliffLength"] = 'cliffLength';
    CommunityRewardsToken_OrderBy["EndTime"] = 'endTime';
    CommunityRewardsToken_OrderBy["GrantedAt"] = 'grantedAt';
    CommunityRewardsToken_OrderBy["Id"] = 'id';
    CommunityRewardsToken_OrderBy["Index"] = 'index';
    CommunityRewardsToken_OrderBy["RevokedAt"] = 'revokedAt';
    CommunityRewardsToken_OrderBy["Source"] = 'source';
    CommunityRewardsToken_OrderBy["StartTime"] = 'startTime';
    CommunityRewardsToken_OrderBy["TotalClaimed"] = 'totalClaimed';
    CommunityRewardsToken_OrderBy["TotalGranted"] = 'totalGranted';
    CommunityRewardsToken_OrderBy["User"] = 'user';
    CommunityRewardsToken_OrderBy["VestingInterval"] = 'vestingInterval';
    CommunityRewardsToken_OrderBy["VestingLength"] = 'vestingLength';
})(CommunityRewardsToken_OrderBy || (CommunityRewardsToken_OrderBy = {}));
var CreditLine_OrderBy;
(function(CreditLine_OrderBy) {
    CreditLine_OrderBy["Balance"] = 'balance';
    CreditLine_OrderBy["Borrower"] = 'borrower';
    CreditLine_OrderBy["Id"] = 'id';
    CreditLine_OrderBy["InterestAccruedAsOf"] = 'interestAccruedAsOf';
    CreditLine_OrderBy["InterestApr"] = 'interestApr';
    CreditLine_OrderBy["InterestAprDecimal"] = 'interestAprDecimal';
    CreditLine_OrderBy["InterestOwed"] = 'interestOwed';
    CreditLine_OrderBy["IsEligibleForRewards"] = 'isEligibleForRewards';
    CreditLine_OrderBy["LastFullPaymentTime"] = 'lastFullPaymentTime';
    CreditLine_OrderBy["LateFeeApr"] = 'lateFeeApr';
    CreditLine_OrderBy["Limit"] = 'limit';
    CreditLine_OrderBy["MaxLimit"] = 'maxLimit';
    CreditLine_OrderBy["NextDueTime"] = 'nextDueTime';
    CreditLine_OrderBy["PaymentPeriodInDays"] = 'paymentPeriodInDays';
    CreditLine_OrderBy["TermEndTime"] = 'termEndTime';
    CreditLine_OrderBy["TermInDays"] = 'termInDays';
    CreditLine_OrderBy["TermStartTime"] = 'termStartTime';
    CreditLine_OrderBy["TranchedPool"] = 'tranchedPool';
    CreditLine_OrderBy["Version"] = 'version';
})(CreditLine_OrderBy || (CreditLine_OrderBy = {}));
var DirectGrantSource;
(function(DirectGrantSource) {
    DirectGrantSource["BackerMerkleDirectDistributor"] = 'BACKER_MERKLE_DIRECT_DISTRIBUTOR';
    DirectGrantSource["MerkleDirectDistributor"] = 'MERKLE_DIRECT_DISTRIBUTOR';
})(DirectGrantSource || (DirectGrantSource = {}));
var GrantReason;
(function(GrantReason) {
    GrantReason["Backer"] = 'BACKER';
    GrantReason["FlightAcademy"] = 'FLIGHT_ACADEMY';
    GrantReason["FlightAcademyAndLiquidityProvider"] = 'FLIGHT_ACADEMY_AND_LIQUIDITY_PROVIDER';
    GrantReason["GoldfinchInvestment"] = 'GOLDFINCH_INVESTMENT';
    GrantReason["LiquidityProvider"] = 'LIQUIDITY_PROVIDER';
})(GrantReason || (GrantReason = {}));
var IndirectGrantSource;
(function(IndirectGrantSource) {
    IndirectGrantSource["BackerMerkleDistributor"] = 'BACKER_MERKLE_DISTRIBUTOR';
    IndirectGrantSource["MerkleDistributor"] = 'MERKLE_DISTRIBUTOR';
})(IndirectGrantSource || (IndirectGrantSource = {}));
var JuniorTrancheInfo_OrderBy;
(function(JuniorTrancheInfo_OrderBy) {
    JuniorTrancheInfo_OrderBy["Id"] = 'id';
    JuniorTrancheInfo_OrderBy["InterestSharePrice"] = 'interestSharePrice';
    JuniorTrancheInfo_OrderBy["LockedUntil"] = 'lockedUntil';
    JuniorTrancheInfo_OrderBy["PrincipalDeposited"] = 'principalDeposited';
    JuniorTrancheInfo_OrderBy["PrincipalSharePrice"] = 'principalSharePrice';
    JuniorTrancheInfo_OrderBy["TrancheId"] = 'trancheId';
    JuniorTrancheInfo_OrderBy["TranchedPool"] = 'tranchedPool';
})(JuniorTrancheInfo_OrderBy || (JuniorTrancheInfo_OrderBy = {}));
var OrderDirection;
(function(OrderDirection) {
    OrderDirection["Asc"] = 'asc';
    OrderDirection["Desc"] = 'desc';
})(OrderDirection || (OrderDirection = {}));
var Pool_Status_Type;
(function(Pool_Status_Type) {
    Pool_Status_Type["Approved"] = 'approved';
    Pool_Status_Type["Completed"] = 'completed';
    Pool_Status_Type["Failed"] = 'failed';
    Pool_Status_Type["InReview"] = 'inReview';
    Pool_Status_Type["ReviewFailed"] = 'reviewFailed';
})(Pool_Status_Type || (Pool_Status_Type = {}));
var SeniorPoolStakedPosition_OrderBy;
(function(SeniorPoolStakedPosition_OrderBy) {
    SeniorPoolStakedPosition_OrderBy["Amount"] = 'amount';
    SeniorPoolStakedPosition_OrderBy["Id"] = 'id';
    SeniorPoolStakedPosition_OrderBy["InitialAmount"] = 'initialAmount';
    SeniorPoolStakedPosition_OrderBy["PositionType"] = 'positionType';
    SeniorPoolStakedPosition_OrderBy["StartTime"] = 'startTime';
    SeniorPoolStakedPosition_OrderBy["TotalRewardsClaimed"] = 'totalRewardsClaimed';
    SeniorPoolStakedPosition_OrderBy["User"] = 'user';
})(SeniorPoolStakedPosition_OrderBy || (SeniorPoolStakedPosition_OrderBy = {}));
var SeniorPoolStatus_OrderBy;
(function(SeniorPoolStatus_OrderBy) {
    SeniorPoolStatus_OrderBy["Balance"] = 'balance';
    SeniorPoolStatus_OrderBy["CompoundBalance"] = 'compoundBalance';
    SeniorPoolStatus_OrderBy["CumulativeDrawdowns"] = 'cumulativeDrawdowns';
    SeniorPoolStatus_OrderBy["CumulativeWritedowns"] = 'cumulativeWritedowns';
    SeniorPoolStatus_OrderBy["DefaultRate"] = 'defaultRate';
    SeniorPoolStatus_OrderBy["EstimatedApy"] = 'estimatedApy';
    SeniorPoolStatus_OrderBy["EstimatedApyFromGfiRaw"] = 'estimatedApyFromGfiRaw';
    SeniorPoolStatus_OrderBy["EstimatedTotalInterest"] = 'estimatedTotalInterest';
    SeniorPoolStatus_OrderBy["Id"] = 'id';
    SeniorPoolStatus_OrderBy["RawBalance"] = 'rawBalance';
    SeniorPoolStatus_OrderBy["RemainingCapacity"] = 'remainingCapacity';
    SeniorPoolStatus_OrderBy["SharePrice"] = 'sharePrice';
    SeniorPoolStatus_OrderBy["TotalLoansOutstanding"] = 'totalLoansOutstanding';
    SeniorPoolStatus_OrderBy["TotalPoolAssets"] = 'totalPoolAssets';
    SeniorPoolStatus_OrderBy["TotalPoolAssetsUsdc"] = 'totalPoolAssetsUsdc';
    SeniorPoolStatus_OrderBy["TotalShares"] = 'totalShares';
    SeniorPoolStatus_OrderBy["TranchedPools"] = 'tranchedPools';
    SeniorPoolStatus_OrderBy["UsdcBalance"] = 'usdcBalance';
})(SeniorPoolStatus_OrderBy || (SeniorPoolStatus_OrderBy = {}));
var SeniorPool_OrderBy;
(function(SeniorPool_OrderBy) {
    SeniorPool_OrderBy["Id"] = 'id';
    SeniorPool_OrderBy["InvestmentsMade"] = 'investmentsMade';
    SeniorPool_OrderBy["LatestPoolStatus"] = 'latestPoolStatus';
})(SeniorPool_OrderBy || (SeniorPool_OrderBy = {}));
var SeniorTrancheInfo_OrderBy;
(function(SeniorTrancheInfo_OrderBy) {
    SeniorTrancheInfo_OrderBy["Id"] = 'id';
    SeniorTrancheInfo_OrderBy["InterestSharePrice"] = 'interestSharePrice';
    SeniorTrancheInfo_OrderBy["LockedUntil"] = 'lockedUntil';
    SeniorTrancheInfo_OrderBy["PrincipalDeposited"] = 'principalDeposited';
    SeniorTrancheInfo_OrderBy["PrincipalSharePrice"] = 'principalSharePrice';
    SeniorTrancheInfo_OrderBy["TrancheId"] = 'trancheId';
    SeniorTrancheInfo_OrderBy["TranchedPool"] = 'tranchedPool';
})(SeniorTrancheInfo_OrderBy || (SeniorTrancheInfo_OrderBy = {}));
var StakedPositionType;
(function(StakedPositionType) {
    StakedPositionType["CurveLp"] = 'CurveLP';
    StakedPositionType["Fidu"] = 'Fidu';
})(StakedPositionType || (StakedPositionType = {}));
var StakingRewardsData_OrderBy;
(function(StakingRewardsData_OrderBy) {
    StakingRewardsData_OrderBy["CurrentEarnRatePerToken"] = 'currentEarnRatePerToken';
    StakingRewardsData_OrderBy["Id"] = 'id';
})(StakingRewardsData_OrderBy || (StakingRewardsData_OrderBy = {}));
var SupportedCrypto;
(function(SupportedCrypto) {
    SupportedCrypto["CurveLp"] = 'CURVE_LP';
    SupportedCrypto["Fidu"] = 'FIDU';
    SupportedCrypto["Gfi"] = 'GFI';
    SupportedCrypto["Usdc"] = 'USDC';
})(SupportedCrypto || (SupportedCrypto = {}));
var SupportedFiat;
(function(SupportedFiat) {
    SupportedFiat["Usd"] = 'USD';
})(SupportedFiat || (SupportedFiat = {}));
var TranchedPoolCreditLineVersion;
(function(TranchedPoolCreditLineVersion) {
    TranchedPoolCreditLineVersion["BeforeV2_2"] = 'BEFORE_V2_2';
    TranchedPoolCreditLineVersion["V2_2"] = 'V2_2';
})(TranchedPoolCreditLineVersion || (TranchedPoolCreditLineVersion = {}));
var TranchedPoolToken_OrderBy;
(function(TranchedPoolToken_OrderBy) {
    TranchedPoolToken_OrderBy["Id"] = 'id';
    TranchedPoolToken_OrderBy["InterestRedeemable"] = 'interestRedeemable';
    TranchedPoolToken_OrderBy["InterestRedeemed"] = 'interestRedeemed';
    TranchedPoolToken_OrderBy["MintedAt"] = 'mintedAt';
    TranchedPoolToken_OrderBy["PrincipalAmount"] = 'principalAmount';
    TranchedPoolToken_OrderBy["PrincipalRedeemable"] = 'principalRedeemable';
    TranchedPoolToken_OrderBy["PrincipalRedeemed"] = 'principalRedeemed';
    TranchedPoolToken_OrderBy["RewardsClaimable"] = 'rewardsClaimable';
    TranchedPoolToken_OrderBy["RewardsClaimed"] = 'rewardsClaimed';
    TranchedPoolToken_OrderBy["StakingRewardsClaimable"] = 'stakingRewardsClaimable';
    TranchedPoolToken_OrderBy["StakingRewardsClaimed"] = 'stakingRewardsClaimed';
    TranchedPoolToken_OrderBy["Tranche"] = 'tranche';
    TranchedPoolToken_OrderBy["TranchedPool"] = 'tranchedPool';
    TranchedPoolToken_OrderBy["User"] = 'user';
})(TranchedPoolToken_OrderBy || (TranchedPoolToken_OrderBy = {}));
var TranchedPool_OrderBy;
(function(TranchedPool_OrderBy) {
    TranchedPool_OrderBy["AllowedUidTypes"] = 'allowedUidTypes';
    TranchedPool_OrderBy["Backers"] = 'backers';
    TranchedPool_OrderBy["CreatedAt"] = 'createdAt';
    TranchedPool_OrderBy["CreditLine"] = 'creditLine';
    TranchedPool_OrderBy["EstimatedJuniorApy"] = 'estimatedJuniorApy';
    TranchedPool_OrderBy["EstimatedJuniorApyFromGfiRaw"] = 'estimatedJuniorApyFromGfiRaw';
    TranchedPool_OrderBy["EstimatedLeverageRatio"] = 'estimatedLeverageRatio';
    TranchedPool_OrderBy["EstimatedSeniorPoolContribution"] = 'estimatedSeniorPoolContribution';
    TranchedPool_OrderBy["EstimatedTotalAssets"] = 'estimatedTotalAssets';
    TranchedPool_OrderBy["FundableAt"] = 'fundableAt';
    TranchedPool_OrderBy["Id"] = 'id';
    TranchedPool_OrderBy["InitialInterestOwed"] = 'initialInterestOwed';
    TranchedPool_OrderBy["InterestAmountRepaid"] = 'interestAmountRepaid';
    TranchedPool_OrderBy["IsPaused"] = 'isPaused';
    TranchedPool_OrderBy["IsV1StyleDeal"] = 'isV1StyleDeal';
    TranchedPool_OrderBy["JuniorDeposited"] = 'juniorDeposited';
    TranchedPool_OrderBy["JuniorFeePercent"] = 'juniorFeePercent';
    TranchedPool_OrderBy["JuniorTranches"] = 'juniorTranches';
    TranchedPool_OrderBy["NumBackers"] = 'numBackers';
    TranchedPool_OrderBy["PrincipalAmountRepaid"] = 'principalAmountRepaid';
    TranchedPool_OrderBy["RemainingCapacity"] = 'remainingCapacity';
    TranchedPool_OrderBy["RemainingJuniorCapacity"] = 'remainingJuniorCapacity';
    TranchedPool_OrderBy["ReserveFeePercent"] = 'reserveFeePercent';
    TranchedPool_OrderBy["SeniorTranches"] = 'seniorTranches';
    TranchedPool_OrderBy["Tokens"] = 'tokens';
    TranchedPool_OrderBy["TotalDeployed"] = 'totalDeployed';
    TranchedPool_OrderBy["TotalDeposited"] = 'totalDeposited';
    TranchedPool_OrderBy["Transactions"] = 'transactions';
    TranchedPool_OrderBy["Version"] = 'version';
})(TranchedPool_OrderBy || (TranchedPool_OrderBy = {}));
var TransactionCategory;
(function(TransactionCategory) {
    TransactionCategory["SeniorPoolDeposit"] = 'SENIOR_POOL_DEPOSIT';
    TransactionCategory["SeniorPoolDepositAndStake"] = 'SENIOR_POOL_DEPOSIT_AND_STAKE';
    TransactionCategory["SeniorPoolRedemption"] = 'SENIOR_POOL_REDEMPTION';
    TransactionCategory["SeniorPoolStake"] = 'SENIOR_POOL_STAKE';
    TransactionCategory["SeniorPoolUnstake"] = 'SENIOR_POOL_UNSTAKE';
    TransactionCategory["SeniorPoolUnstakeAndWithdrawal"] = 'SENIOR_POOL_UNSTAKE_AND_WITHDRAWAL';
    TransactionCategory["SeniorPoolWithdrawal"] = 'SENIOR_POOL_WITHDRAWAL';
    TransactionCategory["TranchedPoolDeposit"] = 'TRANCHED_POOL_DEPOSIT';
    TransactionCategory["TranchedPoolDrawdown"] = 'TRANCHED_POOL_DRAWDOWN';
    TransactionCategory["TranchedPoolRepayment"] = 'TRANCHED_POOL_REPAYMENT';
    TransactionCategory["TranchedPoolWithdrawal"] = 'TRANCHED_POOL_WITHDRAWAL';
    TransactionCategory["UidMinted"] = 'UID_MINTED';
})(TransactionCategory || (TransactionCategory = {}));
var Transaction_OrderBy;
(function(Transaction_OrderBy) {
    Transaction_OrderBy["Amount"] = 'amount';
    Transaction_OrderBy["AmountToken"] = 'amountToken';
    Transaction_OrderBy["BlockNumber"] = 'blockNumber';
    Transaction_OrderBy["Category"] = 'category';
    Transaction_OrderBy["Id"] = 'id';
    Transaction_OrderBy["Timestamp"] = 'timestamp';
    Transaction_OrderBy["TranchedPool"] = 'tranchedPool';
    Transaction_OrderBy["TransactionHash"] = 'transactionHash';
    Transaction_OrderBy["User"] = 'user';
})(Transaction_OrderBy || (Transaction_OrderBy = {}));
var UidType;
(function(UidType) {
    UidType["NonUsEntity"] = 'NON_US_ENTITY';
    UidType["NonUsIndividual"] = 'NON_US_INDIVIDUAL';
    UidType["UsAccreditedIndividual"] = 'US_ACCREDITED_INDIVIDUAL';
    UidType["UsEntity"] = 'US_ENTITY';
    UidType["UsNonAccreditedIndividual"] = 'US_NON_ACCREDITED_INDIVIDUAL';
})(UidType || (UidType = {}));
var User_OrderBy;
(function(User_OrderBy) {
    User_OrderBy["CommunityRewardsTokens"] = 'communityRewardsTokens';
    User_OrderBy["Id"] = 'id';
    User_OrderBy["IsGoListed"] = 'isGoListed';
    User_OrderBy["IsNonUsEntity"] = 'isNonUsEntity';
    User_OrderBy["IsNonUsIndividual"] = 'isNonUsIndividual';
    User_OrderBy["IsUsAccreditedIndividual"] = 'isUsAccreditedIndividual';
    User_OrderBy["IsUsEntity"] = 'isUsEntity';
    User_OrderBy["IsUsNonAccreditedIndividual"] = 'isUsNonAccreditedIndividual';
    User_OrderBy["SeniorPoolStakedPositions"] = 'seniorPoolStakedPositions';
    User_OrderBy["TranchedPoolTokens"] = 'tranchedPoolTokens';
    User_OrderBy["Transactions"] = 'transactions';
    User_OrderBy["Zaps"] = 'zaps';
})(User_OrderBy || (User_OrderBy = {}));
var Zap_OrderBy;
(function(Zap_OrderBy) {
    Zap_OrderBy["Amount"] = 'amount';
    Zap_OrderBy["Id"] = 'id';
    Zap_OrderBy["PoolToken"] = 'poolToken';
    Zap_OrderBy["SeniorPoolStakedPosition"] = 'seniorPoolStakedPosition';
    Zap_OrderBy["TranchedPool"] = 'tranchedPool';
    Zap_OrderBy["User"] = 'user';
})(Zap_OrderBy || (Zap_OrderBy = {}));
var _SubgraphErrorPolicy_;
(function(_SubgraphErrorPolicy_) {
    _SubgraphErrorPolicy_[/** Data will be returned even if the subgraph has indexing errors */ "Allow"] = 'allow';
    _SubgraphErrorPolicy_[/** If the subgraph has indexing errors, data will be omitted. The default. */ "Deny"] = 'deny';
})(_SubgraphErrorPolicy_ || (_SubgraphErrorPolicy_ = {}));
const TranchedPoolStatusFieldsFragmentDoc = _apollo_client__WEBPACK_IMPORTED_MODULE_0__.gql`
    fragment TranchedPoolStatusFields on TranchedPool {
  id
  isPaused
  remainingCapacity
  fundableAt
  creditLine {
    id
    balance
    termEndTime
  }
}
    `;
const UserEligibilityFieldsFragmentDoc = _apollo_client__WEBPACK_IMPORTED_MODULE_0__.gql`
    fragment UserEligibilityFields on User {
  id
  isUsEntity
  isNonUsEntity
  isUsAccreditedIndividual
  isUsNonAccreditedIndividual
  isNonUsIndividual
  isGoListed
}
    `;
const CurrentUserWalletInfoDocument = _apollo_client__WEBPACK_IMPORTED_MODULE_0__.gql`
    query CurrentUserWalletInfo($userAccount: ID!) {
  gfiPrice(fiat: USD) @client {
    price {
      amount
      symbol
    }
  }
  viewer @client {
    account(format: "lowercase") @export(as: "userAccount")
    usdcBalance {
      token
      amount
    }
    gfiBalance {
      token
      amount
    }
  }
  user(id: $userAccount) {
    id
    isUsEntity
    isNonUsEntity
    isUsAccreditedIndividual
    isUsNonAccreditedIndividual
    isNonUsIndividual
    isGoListed
    transactions(orderBy: timestamp, orderDirection: desc, first: 5) {
      id
      timestamp
      transactionHash
      category
      amount
      amountToken
    }
  }
}
    `;
/**
 * __useCurrentUserWalletInfoQuery__
 *
 * To run a query within a React component, call `useCurrentUserWalletInfoQuery` and pass it any options that fit your needs.
 * When your component renders, `useCurrentUserWalletInfoQuery` returns an object from Apollo Client that contains loading, error, and data properties
 * you can use to render your UI.
 *
 * @param baseOptions options that will be passed into the query, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options;
 *
 * @example
 * const { data, loading, error } = useCurrentUserWalletInfoQuery({
 *   variables: {
 *      userAccount: // value for 'userAccount'
 *   },
 * });
 */ function useCurrentUserWalletInfoQuery(baseOptions) {
    const options = {
        ...defaultOptions,
        ...baseOptions
    };
    return Apollo.useQuery(CurrentUserWalletInfoDocument, options);
}
function useCurrentUserWalletInfoLazyQuery(baseOptions) {
    const options = {
        ...defaultOptions,
        ...baseOptions
    };
    return Apollo.useLazyQuery(CurrentUserWalletInfoDocument, options);
}
const StatusCheckStepDocument = _apollo_client__WEBPACK_IMPORTED_MODULE_0__.gql`
    query StatusCheckStep($account: ID!) {
  user(id: $account) {
    id
    isUsEntity
    isNonUsEntity
    isUsAccreditedIndividual
    isUsNonAccreditedIndividual
    isNonUsIndividual
  }
}
    `;
/**
 * __useStatusCheckStepQuery__
 *
 * To run a query within a React component, call `useStatusCheckStepQuery` and pass it any options that fit your needs.
 * When your component renders, `useStatusCheckStepQuery` returns an object from Apollo Client that contains loading, error, and data properties
 * you can use to render your UI.
 *
 * @param baseOptions options that will be passed into the query, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options;
 *
 * @example
 * const { data, loading, error } = useStatusCheckStepQuery({
 *   variables: {
 *      account: // value for 'account'
 *   },
 * });
 */ function useStatusCheckStepQuery(baseOptions) {
    const options = {
        ...defaultOptions,
        ...baseOptions
    };
    return Apollo.useQuery(StatusCheckStepDocument, options);
}
function useStatusCheckStepLazyQuery(baseOptions) {
    const options = {
        ...defaultOptions,
        ...baseOptions
    };
    return Apollo.useLazyQuery(StatusCheckStepDocument, options);
}
const CurrentUserTransactionsDocument = _apollo_client__WEBPACK_IMPORTED_MODULE_0__.gql`
    query CurrentUserTransactions($account: String!, $first: Int!, $skip: Int!) {
  transactions(
    orderBy: timestamp
    orderDirection: desc
    first: $first
    skip: $skip
    where: {user: $account}
  ) {
    id
    transactionHash
    category
    amount
    amountToken
    timestamp
    tranchedPool {
      id
    }
  }
}
    `;
/**
 * __useCurrentUserTransactionsQuery__
 *
 * To run a query within a React component, call `useCurrentUserTransactionsQuery` and pass it any options that fit your needs.
 * When your component renders, `useCurrentUserTransactionsQuery` returns an object from Apollo Client that contains loading, error, and data properties
 * you can use to render your UI.
 *
 * @param baseOptions options that will be passed into the query, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options;
 *
 * @example
 * const { data, loading, error } = useCurrentUserTransactionsQuery({
 *   variables: {
 *      account: // value for 'account'
 *      first: // value for 'first'
 *      skip: // value for 'skip'
 *   },
 * });
 */ function useCurrentUserTransactionsQuery(baseOptions) {
    const options = {
        ...defaultOptions,
        ...baseOptions
    };
    return Apollo.useQuery(CurrentUserTransactionsDocument, options);
}
function useCurrentUserTransactionsLazyQuery(baseOptions) {
    const options = {
        ...defaultOptions,
        ...baseOptions
    };
    return Apollo.useLazyQuery(CurrentUserTransactionsDocument, options);
}
const AllPendingPoolsDocument = _apollo_client__WEBPACK_IMPORTED_MODULE_0__.gql`
    query allPendingPools($filters: PendingPoolFilters) {
  pools(filters: $filters) @rest(path: "pool?{args}", type: "pools") {
    id
    poolName
    walletAddress
    projectCoverImage
    status
    goalAmount
  }
}
    `;
/**
 * __useAllPendingPoolsQuery__
 *
 * To run a query within a React component, call `useAllPendingPoolsQuery` and pass it any options that fit your needs.
 * When your component renders, `useAllPendingPoolsQuery` returns an object from Apollo Client that contains loading, error, and data properties
 * you can use to render your UI.
 *
 * @param baseOptions options that will be passed into the query, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options;
 *
 * @example
 * const { data, loading, error } = useAllPendingPoolsQuery({
 *   variables: {
 *      filters: // value for 'filters'
 *   },
 * });
 */ function useAllPendingPoolsQuery(baseOptions) {
    const options = {
        ...defaultOptions,
        ...baseOptions
    };
    return Apollo.useQuery(AllPendingPoolsDocument, options);
}
function useAllPendingPoolsLazyQuery(baseOptions) {
    const options = {
        ...defaultOptions,
        ...baseOptions
    };
    return Apollo.useLazyQuery(AllPendingPoolsDocument, options);
}
const ArtistGetAllPoolsGraphDataDocument = _apollo_client__WEBPACK_IMPORTED_MODULE_0__.gql`
    query artistGetAllPoolsGraphData {
  tranchedPools {
    id
    backers {
      id
    }
    juniorTranches {
      lockedUntil
    }
    juniorDeposited
    creditLine {
      id
      limit
      maxLimit
    }
  }
}
    `;
/**
 * __useArtistGetAllPoolsGraphDataQuery__
 *
 * To run a query within a React component, call `useArtistGetAllPoolsGraphDataQuery` and pass it any options that fit your needs.
 * When your component renders, `useArtistGetAllPoolsGraphDataQuery` returns an object from Apollo Client that contains loading, error, and data properties
 * you can use to render your UI.
 *
 * @param baseOptions options that will be passed into the query, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options;
 *
 * @example
 * const { data, loading, error } = useArtistGetAllPoolsGraphDataQuery({
 *   variables: {
 *   },
 * });
 */ function useArtistGetAllPoolsGraphDataQuery(baseOptions) {
    const options = {
        ...defaultOptions,
        ...baseOptions
    };
    return Apollo.useQuery(ArtistGetAllPoolsGraphDataDocument, options);
}
function useArtistGetAllPoolsGraphDataLazyQuery(baseOptions) {
    const options = {
        ...defaultOptions,
        ...baseOptions
    };
    return Apollo.useLazyQuery(ArtistGetAllPoolsGraphDataDocument, options);
}
const ArtistPoolMetadataListDocument = _apollo_client__WEBPACK_IMPORTED_MODULE_0__.gql`
    query artistPoolMetadataList($ids: [ID!]!, $walletAddress: String!) {
  poolsByIds(poolIds: $ids, walletAddress: $walletAddress) @rest(path: "pool?{args}", type: "pools") {
    id
    poolName
    walletAddress
    status
    goalAmount
    closingDate
    poolAddress
  }
}
    `;
/**
 * __useArtistPoolMetadataListQuery__
 *
 * To run a query within a React component, call `useArtistPoolMetadataListQuery` and pass it any options that fit your needs.
 * When your component renders, `useArtistPoolMetadataListQuery` returns an object from Apollo Client that contains loading, error, and data properties
 * you can use to render your UI.
 *
 * @param baseOptions options that will be passed into the query, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options;
 *
 * @example
 * const { data, loading, error } = useArtistPoolMetadataListQuery({
 *   variables: {
 *      ids: // value for 'ids'
 *      walletAddress: // value for 'walletAddress'
 *   },
 * });
 */ function useArtistPoolMetadataListQuery(baseOptions) {
    const options = {
        ...defaultOptions,
        ...baseOptions
    };
    return Apollo.useQuery(ArtistPoolMetadataListDocument, options);
}
function useArtistPoolMetadataListLazyQuery(baseOptions) {
    const options = {
        ...defaultOptions,
        ...baseOptions
    };
    return Apollo.useLazyQuery(ArtistPoolMetadataListDocument, options);
}
const PendingPoolsDocument = _apollo_client__WEBPACK_IMPORTED_MODULE_0__.gql`
    query pendingPools($walletAddress: String!, $filters: PendingPoolFilters) {
  pools(walletAddress: $walletAddress, filters: $filters) @rest(path: "pool?{args}", type: "pools") {
    id
    poolName
    walletAddress
    projectCoverImage
    goalAmount
    status
  }
}
    `;
/**
 * __usePendingPoolsQuery__
 *
 * To run a query within a React component, call `usePendingPoolsQuery` and pass it any options that fit your needs.
 * When your component renders, `usePendingPoolsQuery` returns an object from Apollo Client that contains loading, error, and data properties
 * you can use to render your UI.
 *
 * @param baseOptions options that will be passed into the query, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options;
 *
 * @example
 * const { data, loading, error } = usePendingPoolsQuery({
 *   variables: {
 *      walletAddress: // value for 'walletAddress'
 *      filters: // value for 'filters'
 *   },
 * });
 */ function usePendingPoolsQuery(baseOptions) {
    const options = {
        ...defaultOptions,
        ...baseOptions
    };
    return Apollo.useQuery(PendingPoolsDocument, options);
}
function usePendingPoolsLazyQuery(baseOptions) {
    const options = {
        ...defaultOptions,
        ...baseOptions
    };
    return Apollo.useLazyQuery(PendingPoolsDocument, options);
}
const ArtistPoolMetadataDocument = _apollo_client__WEBPACK_IMPORTED_MODULE_0__.gql`
    query artistPoolMetadata($poolId: String!) {
  pool(poolId: $poolId) @rest(path: "pool/{args.poolId}", type: "Pool") {
    id
    poolName
    projectDetail
    walletAddress
    projectCoverImage
    status
    goalAmount
    terms {
      projectGoal
      raiseTarget
    }
    closingDate
    poolAddress
    borrowerContract
  }
}
    `;
/**
 * __useArtistPoolMetadataQuery__
 *
 * To run a query within a React component, call `useArtistPoolMetadataQuery` and pass it any options that fit your needs.
 * When your component renders, `useArtistPoolMetadataQuery` returns an object from Apollo Client that contains loading, error, and data properties
 * you can use to render your UI.
 *
 * @param baseOptions options that will be passed into the query, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options;
 *
 * @example
 * const { data, loading, error } = useArtistPoolMetadataQuery({
 *   variables: {
 *      poolId: // value for 'poolId'
 *   },
 * });
 */ function useArtistPoolMetadataQuery(baseOptions) {
    const options = {
        ...defaultOptions,
        ...baseOptions
    };
    return Apollo.useQuery(ArtistPoolMetadataDocument, options);
}
function useArtistPoolMetadataLazyQuery(baseOptions) {
    const options = {
        ...defaultOptions,
        ...baseOptions
    };
    return Apollo.useLazyQuery(ArtistPoolMetadataDocument, options);
}
const ArtistPoolGraphDataDocument = _apollo_client__WEBPACK_IMPORTED_MODULE_0__.gql`
    query artistPoolGraphData($tranchedPoolAddress: ID!) {
  tranchedPool(id: $tranchedPoolAddress) {
    id
    remainingCapacity
    estimatedJuniorApy
    estimatedJuniorApyFromGfiRaw
    estimatedLeverageRatio
    fundableAt
    isPaused
    numBackers
    backers {
      id
    }
    juniorTranches {
      lockedUntil
    }
    juniorDeposited
    creditLine {
      id
      limit
      maxLimit
      id
      termInDays
      paymentPeriodInDays
      nextDueTime
      interestAprDecimal
      borrower
      lateFeeApr
    }
    initialInterestOwed
    principalAmountRepaid
    totalDeployed
    estimatedTotalAssets
    interestAmountRepaid
    remainingJuniorCapacity
    allowedUidTypes
    ...TranchedPoolStatusFields
  }
}
    ${TranchedPoolStatusFieldsFragmentDoc}`;
/**
 * __useArtistPoolGraphDataQuery__
 *
 * To run a query within a React component, call `useArtistPoolGraphDataQuery` and pass it any options that fit your needs.
 * When your component renders, `useArtistPoolGraphDataQuery` returns an object from Apollo Client that contains loading, error, and data properties
 * you can use to render your UI.
 *
 * @param baseOptions options that will be passed into the query, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options;
 *
 * @example
 * const { data, loading, error } = useArtistPoolGraphDataQuery({
 *   variables: {
 *      tranchedPoolAddress: // value for 'tranchedPoolAddress'
 *   },
 * });
 */ function useArtistPoolGraphDataQuery(baseOptions) {
    const options = {
        ...defaultOptions,
        ...baseOptions
    };
    return Apollo.useQuery(ArtistPoolGraphDataDocument, options);
}
function useArtistPoolGraphDataLazyQuery(baseOptions) {
    const options = {
        ...defaultOptions,
        ...baseOptions
    };
    return Apollo.useLazyQuery(ArtistPoolGraphDataDocument, options);
}
const BackerGetAllPoolsGraphDataDocument = _apollo_client__WEBPACK_IMPORTED_MODULE_0__.gql`
    query backerGetAllPoolsGraphData {
  tranchedPools {
    id
    backers {
      id
    }
    juniorTranches {
      lockedUntil
    }
    juniorDeposited
    creditLine {
      id
      limit
      maxLimit
    }
  }
}
    `;
/**
 * __useBackerGetAllPoolsGraphDataQuery__
 *
 * To run a query within a React component, call `useBackerGetAllPoolsGraphDataQuery` and pass it any options that fit your needs.
 * When your component renders, `useBackerGetAllPoolsGraphDataQuery` returns an object from Apollo Client that contains loading, error, and data properties
 * you can use to render your UI.
 *
 * @param baseOptions options that will be passed into the query, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options;
 *
 * @example
 * const { data, loading, error } = useBackerGetAllPoolsGraphDataQuery({
 *   variables: {
 *   },
 * });
 */ function useBackerGetAllPoolsGraphDataQuery(baseOptions) {
    const options = {
        ...defaultOptions,
        ...baseOptions
    };
    return Apollo.useQuery(BackerGetAllPoolsGraphDataDocument, options);
}
function useBackerGetAllPoolsGraphDataLazyQuery(baseOptions) {
    const options = {
        ...defaultOptions,
        ...baseOptions
    };
    return Apollo.useLazyQuery(BackerGetAllPoolsGraphDataDocument, options);
}
const BackerPoolAddressPoolMetadataDocument = _apollo_client__WEBPACK_IMPORTED_MODULE_0__.gql`
    query backerPoolAddressPoolMetadata($ids: [ID!]!) {
  poolsByIds(poolIds: $ids) @rest(path: "pool?{args}", type: "pools") {
    id
    poolName
    walletAddress
    status
    goalAmount
    closingDate
    poolAddress
  }
}
    `;
/**
 * __useBackerPoolAddressPoolMetadataQuery__
 *
 * To run a query within a React component, call `useBackerPoolAddressPoolMetadataQuery` and pass it any options that fit your needs.
 * When your component renders, `useBackerPoolAddressPoolMetadataQuery` returns an object from Apollo Client that contains loading, error, and data properties
 * you can use to render your UI.
 *
 * @param baseOptions options that will be passed into the query, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options;
 *
 * @example
 * const { data, loading, error } = useBackerPoolAddressPoolMetadataQuery({
 *   variables: {
 *      ids: // value for 'ids'
 *   },
 * });
 */ function useBackerPoolAddressPoolMetadataQuery(baseOptions) {
    const options = {
        ...defaultOptions,
        ...baseOptions
    };
    return Apollo.useQuery(BackerPoolAddressPoolMetadataDocument, options);
}
function useBackerPoolAddressPoolMetadataLazyQuery(baseOptions) {
    const options = {
        ...defaultOptions,
        ...baseOptions
    };
    return Apollo.useLazyQuery(BackerPoolAddressPoolMetadataDocument, options);
}
const BackerPoolMetadataDocument = _apollo_client__WEBPACK_IMPORTED_MODULE_0__.gql`
    query backerPoolMetadata($poolId: String!) {
  pool(poolId: $poolId) @rest(path: "pool/{args.poolId}", type: "Pool") {
    id
    poolName
    projectDetail
    walletAddress
    projectCoverImage
    status
    goalAmount
    terms {
      projectGoal
      raiseTarget
    }
    closingDate
    poolAddress
  }
}
    `;
/**
 * __useBackerPoolMetadataQuery__
 *
 * To run a query within a React component, call `useBackerPoolMetadataQuery` and pass it any options that fit your needs.
 * When your component renders, `useBackerPoolMetadataQuery` returns an object from Apollo Client that contains loading, error, and data properties
 * you can use to render your UI.
 *
 * @param baseOptions options that will be passed into the query, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options;
 *
 * @example
 * const { data, loading, error } = useBackerPoolMetadataQuery({
 *   variables: {
 *      poolId: // value for 'poolId'
 *   },
 * });
 */ function useBackerPoolMetadataQuery(baseOptions) {
    const options = {
        ...defaultOptions,
        ...baseOptions
    };
    return Apollo.useQuery(BackerPoolMetadataDocument, options);
}
function useBackerPoolMetadataLazyQuery(baseOptions) {
    const options = {
        ...defaultOptions,
        ...baseOptions
    };
    return Apollo.useLazyQuery(BackerPoolMetadataDocument, options);
}
const BackerPoolGraphDataDocument = _apollo_client__WEBPACK_IMPORTED_MODULE_0__.gql`
    query backerPoolGraphData($tranchedPoolAddress: ID!) {
  tranchedPool(id: $tranchedPoolAddress) {
    id
    remainingCapacity
    estimatedJuniorApy
    estimatedJuniorApyFromGfiRaw
    estimatedLeverageRatio
    fundableAt
    isPaused
    numBackers
    backers {
      id
    }
    juniorTranches {
      lockedUntil
    }
    juniorDeposited
    creditLine {
      id
      limit
      maxLimit
      id
      termInDays
      paymentPeriodInDays
      nextDueTime
      interestAprDecimal
      borrower
      lateFeeApr
    }
    totalDeployed
    estimatedTotalAssets
    initialInterestOwed
    principalAmountRepaid
    interestAmountRepaid
    remainingJuniorCapacity
    allowedUidTypes
    ...TranchedPoolStatusFields
  }
}
    ${TranchedPoolStatusFieldsFragmentDoc}`;
/**
 * __useBackerPoolGraphDataQuery__
 *
 * To run a query within a React component, call `useBackerPoolGraphDataQuery` and pass it any options that fit your needs.
 * When your component renders, `useBackerPoolGraphDataQuery` returns an object from Apollo Client that contains loading, error, and data properties
 * you can use to render your UI.
 *
 * @param baseOptions options that will be passed into the query, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options;
 *
 * @example
 * const { data, loading, error } = useBackerPoolGraphDataQuery({
 *   variables: {
 *      tranchedPoolAddress: // value for 'tranchedPoolAddress'
 *   },
 * });
 */ function useBackerPoolGraphDataQuery(baseOptions) {
    const options = {
        ...defaultOptions,
        ...baseOptions
    };
    return Apollo.useQuery(BackerPoolGraphDataDocument, options);
}
function useBackerPoolGraphDataLazyQuery(baseOptions) {
    const options = {
        ...defaultOptions,
        ...baseOptions
    };
    return Apollo.useLazyQuery(BackerPoolGraphDataDocument, options);
}


/***/ })

};
;