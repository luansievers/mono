"use strict";
exports.id = 672;
exports.ids = [672];
exports.modules = {

/***/ 6672:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "POOL_CLOUD_URL": () => (/* binding */ POOL_CLOUD_URL),
  "default": () => (/* binding */ handler)
});

// EXTERNAL MODULE: external "axios"
var external_axios_ = __webpack_require__(2167);
var external_axios_default = /*#__PURE__*/__webpack_require__.n(external_axios_);
// EXTERNAL MODULE: external "qs"
var external_qs_ = __webpack_require__(7104);
var external_qs_default = /*#__PURE__*/__webpack_require__.n(external_qs_);
;// CONCATENATED MODULE: ./constants/contract-addresses/index.ts
// For network: aurora_testnet
const CONTRACT_ADDRESSES = {
    USDC: "0x3E0B09aDf6171F5D1aefef567BA6Cf1fb364E080",
    SeniorPool: "0xCc67DeE4a4aFf88F89FfbCbC061E7eCa72f03D63",
    GFI: "0x1e5Ab4d3F3b673e6f2DE6e476149723ca4dB1649",
    Fidu: "0x8F43Fe6670222Dbe0D4F9aaC65C79bb379c9b401",
    UniqueIdentity: "0xCc78cd15d8A0aa9Fececb105A526b773e0789a61",
    Go: "0x171e7405B3F0117Fbe29F3ADa4144cEBfF332870",
    StakingRewards: "0x409929269e47c8a1F5d0Dd54a51A1128f4407378",
    Zapper: "0xF085CaFFfD0D22371eD4B1Bc90c3F5B3f2cb100D",
    CommunityRewards: "0xC467384310CBeFb256BAcDB72A4182516d0169ed",
    BackerRewards: "0x7928feC16DB5b216aAb76e093453324a1bE39832",
    CurvePool: "0x80aa1a80a30055daa084e599836532f3e58c95e2",
    CurveLP: "0x42ec68ca5c2c80036044f3eead675447ab3a8065",
    GoldFinchFactory: "0xe2803904a00C26406ed79dd526A61b03207054b5",
    Borrower: "0x944453e6b95575572D262dA8dd065e6776A18327"
};

;// CONCATENATED MODULE: ./constants/metadata/icons/addem.png
/* harmony default export */ const addem = ({"src":"/_next/static/media/addem.53be8364.png","height":100,"width":100,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAAAAADhZOFXAAAAOklEQVR42iXLIQ4AIRBD0bn/4RDr1iNQgIbMLw189ZKmkRICYtan0CxDGOgrcsbfc+1lNNIZcKd3hgO/UD5qUuwmWwAAAABJRU5ErkJggg=="});
;// CONCATENATED MODULE: ./constants/metadata/icons/almavest.png
/* harmony default export */ const almavest = ({"src":"/_next/static/media/almavest.88d85cbe.png","height":100,"width":100,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAS1BMVEX////+///+/v79/f38/Pz/+vn7+/v5+/z6+vr29vb19fX88O7v8fHx8PD95uLr6+vp6enn6Ojm5ubl5eXj4+Pl2dfa2trU09TU09PFFiHSAAAANklEQVR42j3Gxw3AIAAEwfXhnG1i/5UiBGJeg4QKGFRzTFS3P6//tTvLF2yK7mFk3cwsQ6cmAzL/AW0StJRlAAAAAElFTkSuQmCC"});
;// CONCATENATED MODULE: ./constants/metadata/icons/aspire.png
/* harmony default export */ const aspire = ({"src":"/_next/static/media/aspire.7abbc088.png","height":100,"width":100,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAIAAABLbSncAAAAr0lEQVR42mPgMYvktoziNonkYYgAIm5TEBcoyACidCJ5LKM4euI5uuJ5zKJ4dEFyDDzGkTw2USxHU1m3pbDuSGE5nMpjDjKAAaidY1oCy6FUHqFIHoVIliOpHJPigYIMQA5XZRy3VxTb2iS2lUncPtFcFXE88kA77KNAmiYnMNzNYLiTwdkPUg4UZOA2jwK5JDCaszmOsymO2z+aB8g1j2IAOdcC6BKoc3n0wFyzSADlsi3pSS8fiQAAAABJRU5ErkJggg=="});
;// CONCATENATED MODULE: ./constants/metadata/icons/cauris.png
/* harmony default export */ const cauris = ({"src":"/_next/static/media/cauris.aadd534c.png","height":400,"width":400,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAIAAABLbSncAAAA00lEQVR42gHIADf/AF1D9Ug890xX+IGQ+Iie+VGJ+yOK/Tqc/gBPJfV4cfbKzPaiq/d+lPmmuvhrnfspjf0AZ0v1ran1Z2j3uL30ipz3YYP5n7X5BXf8AJSD9Id99ZGN9oqO94WP98PL92mG+Thw+wCNePSnnfS/u/SMi/Z7gPfBxfZrffg/YfkAYiLzzsf0bVf1k4v1t7b0g4X3oqX3MkT4AFwA84Nl87Cl9Id49aeg9cvJ9Xdx9ktC9wBqKPNcAPNvQvOWg/SNe/RdPfVPKvVcQ/am2HuGU4t5aQAAAABJRU5ErkJggg=="});
;// CONCATENATED MODULE: ./constants/metadata/icons/divibank.png
/* harmony default export */ const divibank = ({"src":"/_next/static/media/divibank.12edce97.png","height":100,"width":100,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAIAAABLbSncAAAAsElEQVR42i2Ouw4BURCGj8rOnssKuo2HkSi0VFo1a+dc9thKonNNVBrJLkInodF5OOPSzfd/+WeGxcqzaJoIdwKcCUtzS/k6hTShcBfAjvIl4I4bFuWNnziEeijdWLgC8FVNilBT+BfEz+rkFqQbbpbcbKnXVv4MuA81iXuQWmH7MitBs67KroCslq+4ocYRkHAgs8+qNTfEC24eQUq6RyndaH7fHUk357ZCHOWEsfJv/c84QjcepRcAAAAASUVORK5CYII="});
;// CONCATENATED MODULE: ./constants/metadata/icons/goldfinch.png
/* harmony default export */ const goldfinch = ({"src":"/_next/static/media/goldfinch.da4d375a.png","height":300,"width":300,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAZlBMVEX+/Pn9+/j8+/j8+vj7+ff6+Pb6+PX59/X49vT39fP29PP29PL08vDy8O/v7ezu6+rt6+rr6ejp5+fm4+Pi4ODg3t7PzM7IxcizsLWrqK6UkJqTj5mPipWJhZGIg4+Ae4luaXpqZHdZNqOfAAAARElEQVR42hXLxxGAMBADQAE2ljiTc4b+m2TY/4KUXC5CEvuGgop0PJZI0JL5PUkYumt/YkCo1+2eMoMf2rJK/uV88EZ9b+IDJm4PG4oAAAAASUVORK5CYII="});
;// CONCATENATED MODULE: ./constants/metadata/icons/lendeast.png
/* harmony default export */ const lendeast = ({"src":"/_next/static/media/lendeast.9794d47d.png","height":2000,"width":2000,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAV1BMVEULEzMKEzMKEzILEjMKEjIKEzMKEzMKEzIKEzMKEzMKEzMKEzMKEzMKEzMKEzMKEzMKEzMKEzIKEzMKEzIKEzMKEzMKEzMKEzMKEzMKEzMKEzIKEzMKEzMX2iifAAAAHXRSTlMAAAAAAAECAgMEBQ0PER8iIyQmKjA2OEZLU1NWWPaxmVcAAAA9SURBVHjaLca3AYAwEATB20d6hPee/uskQBONgCBAfwwR7VyCm5zpuFui4HmvHVfXr9s8Do1SbUUqK0T2ATuwAdcNPgkRAAAAAElFTkSuQmCC"});
;// CONCATENATED MODULE: ./constants/metadata/icons/payjoy.png
/* harmony default export */ const payjoy = ({"src":"/_next/static/media/payjoy.9151ebd1.png","height":100,"width":100,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAVFBMVEX////+//7//v/+/v7+/v39/v39/f37/fr6/Pn0+fHz+PDy8vLt7e3g7dbK4bfC1rG02pKizne2t7ahy3e0tLSXyV+SyVCpp6qAwQCWmZN0vgCIhooGVR2RAAAAPUlEQVR42jXLNxLAIBAEweFWEvLeAf//J0VA0GEj1MkJKAwh5u/ePIgUrrcHpnOPB4az9X8WWsQweupqUAY7DwGoiKCZoQAAAABJRU5ErkJggg=="});
;// CONCATENATED MODULE: ./constants/metadata/icons/quickcheck.png
/* harmony default export */ const quickcheck = ({"src":"/_next/static/media/quickcheck.a3deada9.png","height":100,"width":100,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAIAAABLbSncAAAAtklEQVR42mP4Hq/8LU7xe5LOtxjJb7Hy3xO1gVygIAOIStD4FsDwPd3ie6LWtyCG74maQEEGoFqg6I/pLb/2bgKiH11F30JAcgzfIrm+53v82rcZpDbP/df2NWAJLYZvUYLfc5yAEt+T9b7nu/9cNPHn8unfghmAkmCjJtX+2rn2R3fxr90bvhf5fovkhFiu+S2Q4Vus7Ldo0W/eDEDR7wlqDFDnJmoDGd/jVb4n6X2PV/0WpwQAhS9nQEp8TmoAAAAASUVORK5CYII="});
;// CONCATENATED MODULE: ./constants/metadata/icons/stratos.jpeg
/* harmony default export */ const stratos = ({"src":"/_next/static/media/stratos.105ba683.jpeg","height":3200,"width":3200,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAgACAMBIgACEQEDEQH/xAAnAAEBAAAAAAAAAAAAAAAAAAAABwEBAAAAAAAAAAAAAAAAAAAAAP/aAAwDAQACEAMQAAAAsYP/xAAWEAADAAAAAAAAAAAAAAAAAAAAImL/2gAIAQEAAT8AeT//xAAUEQEAAAAAAAAAAAAAAAAAAAAA/9oACAECAQE/AH//xAAUEQEAAAAAAAAAAAAAAAAAAAAA/9oACAEDAQE/AH//2Q=="});
;// CONCATENATED MODULE: ./constants/metadata/icons/tugende.png
/* harmony default export */ const tugende = ({"src":"/_next/static/media/tugende.50685645.png","height":100,"width":100,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAIAAABLbSncAAAAoUlEQVR42h3OO05CURiF0W//9xjkChijjZWxdSrOxd6WgZAwFwqoqChJKOgIgYTwuhzOhlCvZmn18gcu+61IgMnRfaOQ3Fi9aPV/VT8jfGqa/xF28ISPvs6W6ee7+vq8ThcIBaGQXpUHE7VT9Np5ONZHICUAITrRqX3JoksBSBgqmUvZ7FxssuIBtlUJSp4vATCSbd27LlYtr8+A3ls+WKEbkghFt4kwSeQAAAAASUVORK5CYII="});
;// CONCATENATED MODULE: ./constants/metadata/borrowers.ts











const defaultHeaderColor = "#f8f8f8";
const BORROWER_METADATA = {
    goldfinchTestBorrower: {
        name: "Goldfinch Test Borrower",
        orgType: "Fintech",
        website: "https://goldfinch.finance",
        linkedIn: "https://www.linkedin.com/company/goldfinchfinance/",
        twitter: "https://twitter.com/goldfinch_fi",
        logo: goldfinch.src,
        headerColor: "#483e5e",
        bio: "Lorem ipsum",
        highlights: [
            "lorem",
            "ipsum"
        ]
    },
    payjoy: {
        name: "Payjoy",
        orgType: "Fintech",
        website: "https://www.payjoy.com/",
        linkedIn: "https://www.linkedin.com/company/payjoy/",
        twitter: "https://twitter.com/PayJoy",
        logo: payjoy.src,
        headerColor: defaultHeaderColor,
        bio: "PayJoy offers a buy-now-pay-later product that allows consumers to transform the purchases of mobile phones into monthly installment plans. The company has brought credit to millions of under-served consumers in emerging markets worldwide by collateralizing their smartphone to jumpstart them into the modern credit system. The company, based in San Francisco, California, was founded in 2015.",
        highlights: [
            "Payjoy has raised over $90M in equity and debt from leading investors such as Greylock and Union Square Ventures",
            "The company was founded in 2015, and is Headquartered in San Francisco, California", 
        ]
    },
    aspire: {
        name: "Aspire",
        orgType: "Fintech",
        website: "https://aspireapp.com/",
        linkedIn: "https://www.linkedin.com/company/aspire-sea/",
        twitter: "https://twitter.com/AspireSEA",
        logo: aspire.src,
        headerColor: "#12385b",
        bio: "Aspire is a modern bank for businesses in Southeast Asia. The company provides businesses with seamless payments, savings products, tools to help teams manage their finances, and a range of credit products to help businesses grow. Aspire was founded in 2018 to provide working capital loans for small to medium-sized businesses, and has since grown it's offering to include a suite of different products for its customers.",
        highlights: [
            "Aspire has raised over $150M in debt and equity from renowned global investors like Sequoia, Y Combinator, DST Global Partner, Picus Capital and more",
            "Over 10,000 businesses have opened accounts with Aspire, and they transact over $2 billion annually",
            "Aspire is headquartered in Singapore, and has operations in Indonesia and Vietnam", 
        ]
    },
    quickcheck: {
        name: "QuickCheck",
        orgType: "Fintech",
        website: "https://quickcheck.ng/",
        linkedIn: "https://www.linkedin.com/company/quickcheck-nigeria/",
        twitter: "https://twitter.com/quickcheckng",
        logo: quickcheck.src,
        headerColor: "#f25f22",
        bio: "QuickCheck is a Nigerian consumer lender that uses machine learning to provide loans instantly to its customers. Through their mobile app, customers can apply for loans and have them funded within minutes.",
        highlights: [
            "QuickCheck has disbursed over $10M in loans since inception, and is growing rapidly",
            "The company has was founded in 2018, and is headquartered in Lagos, Nigeria", 
        ]
    },
    almavest: {
        name: "Almavest",
        orgType: "Credit Fund",
        website: "https://www.almavest.com//",
        linkedIn: "https://www.linkedin.com/company/almavest-impact/",
        logo: almavest.src,
        headerColor: defaultHeaderColor,
        bio: "ALMA Sustainable Finance is an investment management firm that creatively deploys capital for sustainable development. Our debt platform serves high-growth, impact-oriented companies in a range of sectors, primarily in emerging and developing markets in Asia, Africa, and Latin America. ALMA invests in market-leading, impactful businesses led by experienced teams. Our portfolio companies and pipeline borrowers are backed by the world's leading equity investors including Y Combinator, Acumen, Exxon Mobil, GE, FMO, and others. With prior executive or management roles at institutions such as CGAP (World Bank), FinDev Canada, SKS Microfinance (IPO), FastCash (acquired), Rainforest Alliance, and others, our leadership team has nearly 100 combined years of experience in building, scaling and exiting sustainable impact companies, impact debt and equity investing, and data analytics.",
        highlights: [
            "Since launch in 2020, we've deployed nearly $40 million to 11 companies with diverse underlying exposure — to multiple economic sectors and nearly 20 different global markets across Asia, Africa, and Latin America",
            "We have access to proprietary dealflow by virtue of our experience working at, and long-term relationships with, the world's leading sustainable impact organizations and investors",
            "Decades of starting, building, scaling, and exiting impact enterprises across the globe help us attract and vet the teams we fund",
            "We are committed to sustainability - commercially and for society - while prizing creativity, transparency, relationships, experience, and humility", 
        ]
    },
    tugende: {
        name: "Tugende",
        orgType: "Fintech",
        website: "https://gotugende.com/",
        linkedIn: "https://www.linkedin.com/company/tugende/",
        twitter: "https://twitter.com/tugende1",
        logo: tugende.src,
        headerColor: "#eb0c6e",
        bio: "Tugende is tackling the credit gap for small businesses in Africa by enabling informal entrepreneurs to own income-generating assets and build a verifiable digital credit profile based on real-world earning. Starting with motorcycle taxi operators, Tugende uses asset finance, technology, and a customer-centric model to help these entrepreneurs increase their economic trajectory.",
        highlights: [
            "Tugende have raised over $50M in equity from global debt and equity investors",
            "They have over 28,000 active clients",
            "21,000 assets have already been fully owned by alumni clients",
            "They employ over 750 full-time staff in Kenya and Uganda", 
        ]
    },
    divibank: {
        name: "Divibank",
        orgType: "Fintech",
        website: "https://divibank.co/home",
        linkedIn: "https://www.linkedin.com/company/divibank/",
        logo: divibank.src,
        headerColor: "#0f1078",
        bio: "Divibank is a data-driven financing platform that helps online businesses in Latin America scale by providing quick and affordable growth capital. The company provides revenue share loans along with a marketing analytics product to help online businesses scale in a capital-efficient way.",
        highlights: [
            "Divibank has raised over $8M in equity and debt funding to date from renowned global investors",
            "The Divibank team has deep product and financial services experience, having worked at Goldman Sachs, JP Morgan, Itau and Amazon", 
        ]
    },
    cauris: {
        name: "Cauris",
        orgType: "Credit Fund",
        website: "https://www.caurisfinance.com/",
        linkedIn: "https://www.linkedin.com/company/cauris-inc/",
        twitter: "https://twitter.com/Caurisfinance",
        logo: cauris.src,
        headerColor: "#681FF4",
        bio: "Cauris is a mission-driven investment firm that provides private credit to financial technology companies in emerging markets. Working across the Global South—with financings in Africa, Asia and Latin America—Cauris partners with fintechs that are making financial inclusion a reality for tens of millions of consumers and small businesses. Through debt investments, we enable our partners to scale efforts that provide the traditionally underbanked access to financial services that improve their lives. Leveraging Decentralized Finance (DeFi), we aim to facilitate efforts that extend financial services to 100M people because we believe access to credit is key to empowering individuals and small businesses; enabling economic growth in emerging markets; and accelerating the growth of the global middle class.",
        highlights: [
            "Founded by a team of former fintech entrepreneurs, operators, investment professionals, and bankers with expertise in credit and structured finance, direct experience working with fintechs in the Global South, and deep industry experience in financial inclusion",
            "Growing portfolio of fintech investments are supported by disciplined and robust underwriting while enabling our fintechs partners to continue innovating and growing",
            "Cauris has committed over US$85M in lending to best-in-class fintechs in Africa, Asia and Latin America; borrowers are backed by marquee equity investors like A16Z, Tiger Global and the World Bank",
            "Strong performance track record with $15M borrowed on Goldfinch to date, generating healthy risk-adjusted yields for investors with zero delays or defaults in borrower repayments",
            "Cauris is targeting to fund at least US$100M in diversified lending opportunities on the Goldfinch protocol over the next year", 
        ]
    },
    stratos: {
        name: "Stratos",
        orgType: "Credit Fund",
        website: "https://www.stratos.xyz/",
        linkedIn: "https://www.linkedin.com/company/stratosxyz/",
        twitter: "https://twitter.com/StratosXYZ",
        logo: stratos.src,
        headerColor: defaultHeaderColor,
        bio: "Stratos provides highly structured financing solutions to technology and technology-enabled businesses largely in the United States. We pride ourselves in developing and nurturing strong relationships with company founders. Stratos tailors creative financing solutions that help companies grow while providing excellent, consistent returns for our investors with strong downside protection. Stratos credit has invested over $250 million dollars over the past 4 years across 21 investments. We've evaluated over 250 companies in that same time period. The Stratos representative credit fund, our Evergreen Structured Credit Fund (“SCF”), has generated an annualized Gross and Net Cash Return of 16.74% and 12.53%, respectively, since inception in 2016, and a Net Cash Return of 15.44% in 2021. Additionally, SCF has generated an annualized Gross and Net Total Return of 18.95% and 14.41%, respectively, since inception and a Net Total Return of 18.11% in 2021.",
        highlights: [
            "Stratos' Founding Partner, Rennick Palley is a founding team member of Warbler Labs and helped design and set the strategy for the Goldfinch protocol",
            "Stratos has never had a late payment, missed payment, or default in 5 years (60 months) of operation",
            "Since its inception in 2016, the Stratos Evergreen Structured Credit Fund (“SCF”), our longest-running credit-focused strategy, has generated gross annualized total returns of 18.95%",
            "Of the 21 companies that Stratos has lent to since inception, each has grown considerably, with multiple unicorns created in partnership with Stratos credit facilities",
            "Stratos has not had a business fail during or after financing since its inception in 2016",
            "Stratos is targeting to fund at least $100 million in opportunities on the Goldfinch protocol over the next 2 years, across 4 or more deals per year", 
        ]
    },
    lendeast: {
        name: "Lendeast",
        orgType: "Credit Fund",
        website: "https://lendeast.com/",
        linkedIn: "https://www.linkedin.com/company/lend-east/",
        logo: lendeast.src,
        headerColor: defaultHeaderColor,
        bio: "Lend East is a digital lending platform that connects global institutional capital with alternate lenders in Emerging Asia (Southeast Asia & India). Lend East is revolutionising alternate lending by offering scalable growth capital with zero dilution to technology ventures. Leveraging Spa{R}\xb3k, its proprietary credit and risk analytics platform, Lend East has made high impact investments in Indonesia, the Philippines, Singapore & Vietnam since 2019.",
        highlights: [
            "Since inception, Lend East has evaluated over 100 alternate lenders and onboarded 60+ of them on Spa{R}\xb3k, its proprietary credit analytics & risk platform",
            "Lend East has committed US$50mn in investments across seven market leading platforms across Singapore, Indonesia, Philippines, Vietnam & India",
            "Strong performance track record, generating healthy risk adjusted yields for investors with no delays or defaults in borrower repayments", 
        ]
    },
    addem: {
        name: "Addem Capital",
        orgType: "Credit Fund",
        website: "https://addem-capital.com/",
        linkedIn: "https://www.linkedin.com/company/addem-capital/",
        twitter: "https://twitter.com/AddemCapital",
        logo: addem.src,
        headerColor: defaultHeaderColor,
        bio: "Addem Capital has developed a three-entity approach (Fund, Boutique Consulting Firm, Master Servicer) to increase liquidity in the LATAM capital markets, acting as scouts, funders, and monitoring agents within five verticals: fintech, real estate, energy, agriculture/sustainable foods, and healthcare.\n\nAddem Capital aims to become LATAM's most relevant liquidity provider by eliminating unnecessary debt intermediaries while reaching excellence in its underwriting and servicing processes.\n\nAll the monitoring and revisions on the collateral of the credit facilities are done by Addem's Master Servicer. Through its Internal Control Desk, it guarantees that all the performing assets satisfy the eligibility criteria for each facility. This enables Addem to hold more decision-making power on the line and be ahead of relevant risks.",
        highlights: [
            "Addem's fund and consulting firm (Latus) have invested and worked in more than five countries, including Mexico, Colombia, Chile, Brazil, and US-based entrepreneurs working in LATAM.",
            "Addem has evaluated and assessed +200 companies seeking financing and originated more than ten regional deals.",
            "Addem's internal control desk has audited +15,000 individual credits underwritten by their portfolio companies and pledged as collateral and source of payment for their debt facilities.",
            "After receiving debt from Addem Capital, all of their portfolio companies have secured Series A equity rounds with renowned investors such as Accel, Monashees, Y Combinator, Mouro Capital (Santander and SV LATAM).",
            "Addem's three-entity approach enables them to fully service. It monitors ongoing facilities without reducing efforts on scouting new opportunities to consolidate their pipeline and avoiding the reliance on third-party services to properly assess the quality of the asset originators' underwriting process and the asset itself.",
            "In Addem's first year of existence, it was recognized by Catalyst Fund and Brighter as one of the top 100 fintech investors across emerging markets.", 
        ]
    }
};

;// CONCATENATED MODULE: ./constants/metadata/localhost.json
const localhost_namespaceObject = {};
;// CONCATENATED MODULE: ./constants/metadata/index.ts

/* harmony default export */ const metadata = ((/* unused pure expression or super */ null && (localhostMetadata)));

;// CONCATENATED MODULE: ./constants/index.ts



const networkName = "aurora_testnet";
if (!networkName) {
    throw new Error("Network name is not defined in env vars");
}
const DESIRED_CHAIN_ID = networkName === "mainnet" ? 1 : networkName === "aurora_testnet" ? 1313161555 : 31337;
const USDC_DECIMALS = 6;
const GFI_DECIMALS = 18;
const FIDU_DECIMALS = 18;
const CURVE_LP_DECIMALS = 18;
const TRANCHES = {
    Senior: 1,
    Junior: 2
};
const API_BASE_URL =  true ? "https://us-central1-free-artists.cloudfunctions.net" : 0;
const PERSONA_CONFIG = process.env.NEXT_PUBLIC_PERSONA_TEMPLATE && process.env.NEXT_PUBLIC_PERSONA_ENVIRONMENT ? {
    templateId: process.env.NEXT_PUBLIC_PERSONA_TEMPLATE,
    environment: process.env.NEXT_PUBLIC_PERSONA_ENVIRONMENT
} : networkName === "mainnet" ? {
    templateId: "tmpl_vD1HECndpPFNeYHaaPQWjd6H",
    environment: "production"
} : {
    templateId: "tmpl_vD1HECndpPFNeYHaaPQWjd6H",
    environment: "sandbox"
};
const SERVER_URL = networkName === "mainnet" ? "" : networkName === "aurora_testnet" ? "https://us-central1-free-artists.cloudfunctions.net" : "http://localhost:4000";
const UNIQUE_IDENTITY_SIGNER_URL = networkName === "aurora_testnet" ? "https://api.defender.openzeppelin.com/autotasks/8320d42c-98bb-4b53-94e1-aad0628a0892/runs/webhook/356c72eb-f56c-443a-90c3-2b6040ee76b8/E4m9oGprLmtMba6GELSPcS" : "https://api.defender.openzeppelin.com/autotasks/8320d42c-98bb-4b53-94e1-aad0628a0892/runs/webhook/356c72eb-f56c-443a-90c3-2b6040ee76b8/E4m9oGprLmtMba6GELSPcS";
const UNIQUE_IDENTITY_MINT_PRICE = "830000000000000";
const TOKEN_LAUNCH_TIME = 1641920400; // Tuesday, January 11, 2022 09:00:00 AM GMT-08:00 (note that this number is in seconds, not ms)

// EXTERNAL MODULE: ./lib/graphql/generated.ts
var generated = __webpack_require__(2209);
;// CONCATENATED MODULE: ./pages/api/pool/index.page.ts



//Added because ESlint import order was complaining. But this order works fine in pages
// eslint-disable-next-line import/order

const POOL_CLOUD_URL = `${API_BASE_URL}/poolMetaData`;
const filterByWalletAddress = (poolData, walletAddress)=>{
    return poolData.filter((pool)=>pool.walletAddress === walletAddress
    );
};
const filterByPoolAddress = (poolData, poolAddress)=>{
    return poolData.filter((pool)=>pool.poolAddress === poolAddress
    );
};
const filterByPoolIds = (poolData, poolIds)=>{
    return poolData.filter((pool)=>poolIds.includes(pool.poolAddress)
    );
};
const filterPoolDataByUsingFilters = (poolData, filters)=>{
    const { statusType , hasPoolAddress: _hasPoolAddress  } = filters;
    return poolData.filter((pool)=>{
        // Check if statusType filter is provided and current pool's status is matching with passed in statuses
        if (statusType && !statusType.includes(pool.status)) {
            return false;
        }
        if (_hasPoolAddress != undefined) {
            /**
       * Check if poolAddress param is provided
       * If it's value is true only pools with that pool address is returned
       * If it's value is false pools without the pool address are returned
       */ const hasPoolAddress = _hasPoolAddress.toString().toLowerCase() == "true";
            if (hasPoolAddress && !pool.poolAddress) {
                return false;
            }
            if (!hasPoolAddress && !!pool.poolAddress) {
                return false;
            }
        }
        return true;
    });
};
/**
 * This method is used to fetch all pools and create a new pool
 * TODO: Add necessary typings
 *
 */ async function handler(req, res) {
    const { method  } = req;
    switch(method){
        case "GET":
            {
                try {
                    const poolDataResponse = await external_axios_default().get(POOL_CLOUD_URL);
                    let fileData = poolDataResponse.data;
                    const { walletAddress , filters , poolAddress , poolIds ,  } = external_qs_default().parse(req.query);
                    if (walletAddress != undefined) {
                        fileData = filterByWalletAddress(fileData, walletAddress);
                    }
                    if (poolAddress != undefined) {
                        fileData = filterByPoolAddress(fileData, poolAddress);
                    }
                    if (filters) {
                        fileData = filterPoolDataByUsingFilters(fileData, filters);
                    }
                    if (poolIds) {
                        fileData = filterByPoolIds(fileData, poolIds);
                    }
                    res.status(200).json(fileData);
                } catch (error) {
                    console.error(error);
                    res.status(405).end("Error occurred during fetching");
                }
                break;
            }
        case "POST":
            {
                const newPoolData = req.body.params;
                const id = Date.now().toString(36);
                newPoolData.status = generated/* Pool_Status_Type.InReview */.k$.InReview;
                newPoolData.id = id;
                await external_axios_default().post(POOL_CLOUD_URL, {
                    poolData: {
                        id: id,
                        data: newPoolData
                    }
                });
                //await sendToDiscord(newPoolData);
                res.status(200).json(newPoolData);
                break;
            }
        default:
            res.setHeader("Allow", [
                "GET",
                "POST"
            ]);
            res.status(405).end(`Method ${method} Not Allowed`);
    }
    /**
   * Endpoint for Discord webhook
   *
   * @param {IPool} poolData - Pool data
   * @returns {Promise<void>}
   */ async function sendToDiscord(poolData) {
        const discordURL = process.env.DISCORD_WEBHOOK_URL;
        const flame = String.fromCodePoint(128293);
        const data = JSON.stringify({
            content: `@here New Free Artists Pool Proposal ${flame}`,
            embeds: [
                {
                    color: 5174599,
                    fields: [
                        {
                            name: "Pool name",
                            value: poolData.poolName
                        },
                        {
                            name: "Project Detail",
                            value: poolData.projectDetail
                        },
                        {
                            name: "Goal Amount",
                            value: poolData.goalAmount
                        },
                        {
                            name: "Closing Date",
                            value: poolData.closingDate
                        },
                        {
                            name: "Project Goal",
                            value: poolData.terms.projectGoal
                        },
                        {
                            name: "Project Raise Type",
                            value: poolData.terms.raiseTarget
                        }, 
                    ],
                    footer: {
                        text: `Artists Wallet: ${poolData.walletAddress}`
                    }
                }, 
            ]
        });
        return external_axios_default().post(discordURL, data, {
            headers: {
                "Content-Type": "application/json",
                Connection: "keep-alive"
            },
            responseType: "arraybuffer"
        });
    }
};


/***/ })

};
;