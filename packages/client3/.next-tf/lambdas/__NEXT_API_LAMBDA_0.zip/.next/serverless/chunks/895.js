"use strict";
exports.id = 895;
exports.ids = [895];
exports.modules = {

/***/ 6895:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Lk": () => (/* binding */ hasUid),
/* harmony export */   "eV": () => (/* binding */ grantAccountBorrowerPrivileges)
/* harmony export */ });
/* unused harmony export getKYCStatus */
/* harmony import */ var ethers_lib_utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2522);
/* harmony import */ var ethers_lib_utils__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(ethers_lib_utils__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _lib_verify__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1945);


const BORROWER_ROLE = (0,ethers_lib_utils__WEBPACK_IMPORTED_MODULE_0__.keccak256)((0,ethers_lib_utils__WEBPACK_IMPORTED_MODULE_0__.toUtf8Bytes)("BORROWER_ROLE"));
// ! NOTE: Below is the code to grant owner privileges:
const OWNER_ROLE = (0,ethers_lib_utils__WEBPACK_IMPORTED_MODULE_0__.keccak256)((0,ethers_lib_utils__WEBPACK_IMPORTED_MODULE_0__.toUtf8Bytes)("OWNER_ROLE"));
const hasUid = (user)=>{
    return Boolean((user === null || user === void 0 ? void 0 : user.isGoListed) || (user === null || user === void 0 ? void 0 : user.isUsNonAccreditedIndividual) || (user === null || user === void 0 ? void 0 : user.isNonUsIndividual) || (user === null || user === void 0 ? void 0 : user.isUsEntity) || (user === null || user === void 0 ? void 0 : user.isNonUsEntity) || (user === null || user === void 0 ? void 0 : user.isUsAccreditedIndividual));
};
/**
 *
 * @param account - GoldfinchFactory contract
 * @param provider - address of borrower
 * @param user - user object
 * @Promise ContractReceipt - transaction receipt of granting borrower privileges
 */ const getKYCStatus = async (account, provider, user)=>{
    if (hasUid(user)) {
        return user;
    } else {
        const signature = await getSignatureForKyc(provider);
        const kycStatus = await fetchKycStatus(account, signature.signature, signature.signatureBlockNum);
        return kycStatus;
    }
};
/**
 * @param goldfinchFactory - GoldfinchFactory contract
 * @param account - address of borrower
 * @Promise ContractTransaction - transaction receipt of granting borrower privileges
 */ const grantAccountBorrowerPrivileges = async (goldfinchFactory, account)=>{
    // ! NOTE: Below is the code to grant owner privileges:
    // return await goldfinchFactory.grantRole(
    //   OWNER_ROLE,
    //   account
    // );
    return await goldfinchFactory.grantRole(BORROWER_ROLE, account);
};


/***/ })

};
;