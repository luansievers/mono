"use strict";
exports.id = 993;
exports.ids = [993];
exports.modules = {

/***/ 7168:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "E": () => (/* reexport */ Progress)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "clsx"
var external_clsx_ = __webpack_require__(8103);
var external_clsx_default = /*#__PURE__*/__webpack_require__.n(external_clsx_);
;// CONCATENATED MODULE: ./components/design-system/progress/progress.tsx


function Progress({ percentage , type , className  }) {
    return(/*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: external_clsx_default()("h-3 w-full rounded-full bg-green-90/70", className),
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: external_clsx_default()("h-3 rounded-full", {
                "bg-accent-2": !type,
                "bg-accent-2-opacity": type == "completed",
                "bg-accent-3-opacity": type == "failed"
            }),
            style: {
                width: `${percentage}%`
            }
        })
    }));
}

;// CONCATENATED MODULE: ./components/design-system/progress/index.tsx



/***/ }),

/***/ 398:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ BackersList)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _design_system__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1490);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_design_system__WEBPACK_IMPORTED_MODULE_2__]);
_design_system__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



function BackersList({ className , backersList , maxItems =9  }) {
    const { 0: viewAllItems , 1: setViewAllItems  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const backersListToShow = viewAllItems ? backersList : backersList.slice(0, maxItems);
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: className,
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex justify-between",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_design_system__WEBPACK_IMPORTED_MODULE_2__/* .BodyText */ .Ac, {
                                size: "normal",
                                className: " text-dark-50",
                                children: "Total"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_design_system__WEBPACK_IMPORTED_MODULE_2__/* .BodyText */ .Ac, {
                                size: "normal",
                                semiBold: true,
                                className: "pl-2 text-light-40",
                                children: `${backersList.length} Backers`
                            })
                        ]
                    }),
                    backersList.length ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_design_system__WEBPACK_IMPORTED_MODULE_2__/* .Link */ .rU, {
                        href: "",
                        className: "cursor-pointer text-light-20",
                        onClick: ()=>{
                            setViewAllItems((currentVal)=>!currentVal
                            );
                        },
                        useNextLink: false,
                        children: viewAllItems ? "Show less" : "View All"
                    }) : null
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "grid grid-cols-3 gap-4",
                children: backersListToShow.map((backer)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "mt-8 flex items-center break-all",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_design_system__WEBPACK_IMPORTED_MODULE_2__/* .Avatar */ .qE, {
                                size: 12,
                                image: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAAdUlEQVR42mNgGAWjAAj+48GUG37i92+cmFJL/hMDKLHkv1TeVYKYIgvwBQ81gommFvxHtqB0797/6BbCxMixAGzA7AcPUFyJzEcWI9sHxAQP1YIIGWPzCVUjeehbQLN8gK2wG1o+oElpSiiIqFoXUKuCoboFAP+MJG7jSOWlAAAAAElFTkSuQmCC"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_design_system__WEBPACK_IMPORTED_MODULE_2__/* .BodyText */ .Ac, {
                                className: "pl-3 text-white",
                                size: "normal",
                                children: backer.name
                            })
                        ]
                    }, backer.name)
                )
            })
        ]
    }));
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8926:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* reexport safe */ _backers_list__WEBPACK_IMPORTED_MODULE_0__.Z)
/* harmony export */ });
/* harmony import */ var _backers_list__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(398);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_backers_list__WEBPACK_IMPORTED_MODULE_0__]);
_backers_list__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5865:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "q": () => (/* reexport safe */ _pool_details__WEBPACK_IMPORTED_MODULE_0__.q)
/* harmony export */ });
/* harmony import */ var _pool_details__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8283);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_pool_details__WEBPACK_IMPORTED_MODULE_0__]);
_pool_details__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8283:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "q": () => (/* binding */ PoolDetail)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5675);
/* harmony import */ var _components_design_system__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1490);
/* harmony import */ var _components_design_system_button_social_media_button__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9170);
/* harmony import */ var _components_pool_backers_list__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8926);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_design_system__WEBPACK_IMPORTED_MODULE_2__, _components_design_system_button_social_media_button__WEBPACK_IMPORTED_MODULE_3__, _components_pool_backers_list__WEBPACK_IMPORTED_MODULE_4__]);
([_components_design_system__WEBPACK_IMPORTED_MODULE_2__, _components_design_system_button_social_media_button__WEBPACK_IMPORTED_MODULE_3__, _components_pool_backers_list__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);





function PoolDetail({ poolData , backerList  }) {
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "relative mt-3 h-[668px] w-full",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_image__WEBPACK_IMPORTED_MODULE_1__["default"], {
                    alt: "Mountains",
                    src: "/images/free-artists-bg.png",
                    layout: "fill",
                    objectFit: "contain"
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "mt-8 flex items-center",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_design_system__WEBPACK_IMPORTED_MODULE_2__/* .Avatar */ .qE, {
                        size: 15,
                        image: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAAdUlEQVR42mNgGAWjAAj+48GUG37i92+cmFJL/hMDKLHkv1TeVYKYIgvwBQ81gommFvxHtqB0797/6BbCxMixAGzA7AcPUFyJzEcWI9sHxAQP1YIIGWPzCVUjeehbQLN8gK2wG1o+oElpSiiIqFoXUKuCoboFAP+MJG7jSOWlAAAAAElFTkSuQmCC"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_design_system__WEBPACK_IMPORTED_MODULE_2__/* .BodyText */ .Ac, {
                        className: "pl-3 text-white",
                        size: "large",
                        semiBold: true,
                        children: poolData === null || poolData === void 0 ? void 0 : poolData.walletAddress
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_design_system__WEBPACK_IMPORTED_MODULE_2__/* .Heading */ .X6, {
                className: "mt-10 text-white",
                level: 5,
                children: "Project Detail"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_design_system__WEBPACK_IMPORTED_MODULE_2__/* .BodyText */ .Ac, {
                size: "normal",
                className: "mt-6 text-white",
                children: poolData === null || poolData === void 0 ? void 0 : poolData.projectDetail
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_design_system__WEBPACK_IMPORTED_MODULE_2__/* .Heading */ .X6, {
                className: "mt-10 text-white",
                level: 5,
                children: "Social Media Updates"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "mt-6 flex flex-col items-center rounded-lg bg-green-100",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_design_system__WEBPACK_IMPORTED_MODULE_2__/* .BodyText */ .Ac, {
                        className: "pt-12 text-dark-50",
                        size: "medium",
                        children: "Join the community to get updates"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "mt-6 mb-12 grid grid-cols-2 gap-4",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_design_system_button_social_media_button__WEBPACK_IMPORTED_MODULE_3__/* .SocialMediaButton */ .F, {
                                iconLeft: "TwitterLogoOutlined",
                                children: "Twitter"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_design_system_button_social_media_button__WEBPACK_IMPORTED_MODULE_3__/* .SocialMediaButton */ .F, {
                                iconLeft: "DiscordLogoOutlined",
                                children: "Discord"
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_design_system__WEBPACK_IMPORTED_MODULE_2__/* .Heading */ .X6, {
                className: "mt-10 text-white",
                level: 5,
                children: "Backers"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_pool_backers_list__WEBPACK_IMPORTED_MODULE_4__/* .BackersList */ .Z, {
                backersList: backerList !== null && backerList !== void 0 ? backerList : [],
                className: "mt-6"
            })
        ]
    }));
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9351:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "F": () => (/* reexport safe */ _pool_documents__WEBPACK_IMPORTED_MODULE_0__.F)
/* harmony export */ });
/* harmony import */ var _pool_documents__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6130);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_pool_documents__WEBPACK_IMPORTED_MODULE_0__]);
_pool_documents__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6130:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "F": () => (/* binding */ PoolDocuments)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_design_system__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1490);
/* harmony import */ var _components_upload_pdf_upload_pdf__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3421);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_design_system__WEBPACK_IMPORTED_MODULE_1__, _components_upload_pdf_upload_pdf__WEBPACK_IMPORTED_MODULE_2__]);
([_components_design_system__WEBPACK_IMPORTED_MODULE_1__, _components_upload_pdf_upload_pdf__WEBPACK_IMPORTED_MODULE_2__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);



function PoolDocuments() {
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "mt-9 rounded-lg border border-dark-90 p-6",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_design_system__WEBPACK_IMPORTED_MODULE_1__/* .Heading */ .X6, {
                className: "text-white",
                level: 5,
                children: "Documents"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_upload_pdf_upload_pdf__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                className: "mt-7",
                uploadedFile: {
                    fileName: "Pool Contract.pdf",
                    fileUrl: "/artist/dummyUrl"
                }
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_upload_pdf_upload_pdf__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                className: "mt-4",
                uploadedFile: {
                    fileName: "Term Sheeet.pdf",
                    fileUrl: "/artist/dummyUrl"
                }
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_upload_pdf_upload_pdf__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                className: "mt-4",
                uploadedFile: {
                    fileName: "Proposal.pdf",
                    fileUrl: "/artist/dummyUrl"
                }
            })
        ]
    }));
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5001:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "R": () => (/* reexport safe */ _pool_terms__WEBPACK_IMPORTED_MODULE_0__.R)
/* harmony export */ });
/* harmony import */ var _pool_terms__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6437);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_pool_terms__WEBPACK_IMPORTED_MODULE_0__]);
_pool_terms__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6437:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "R": () => (/* binding */ PoolTerms)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_design_system__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1490);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_design_system__WEBPACK_IMPORTED_MODULE_1__]);
_components_design_system__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


function PoolTerms({ terms  }) {
    var ref, ref1;
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "mt-9 rounded-lg border border-dark-90 p-6",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_design_system__WEBPACK_IMPORTED_MODULE_1__/* .Heading */ .X6, {
                className: "text-white",
                level: 5,
                children: "Terms"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "mt-6 flex items-center",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_design_system__WEBPACK_IMPORTED_MODULE_1__/* .BodyText */ .Ac, {
                        size: "normal",
                        className: "text-dark-50",
                        children: "Project Goal"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_design_system__WEBPACK_IMPORTED_MODULE_1__/* .Icon */ .JO, {
                        className: "ml-2",
                        size: "text",
                        name: "InfoCircleOutlined"
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_design_system__WEBPACK_IMPORTED_MODULE_1__/* .BodyText */ .Ac, {
                size: "medium",
                semiBold: true,
                className: "mt-3 text-light-40",
                children: (ref = terms === null || terms === void 0 ? void 0 : terms.projectGoal) !== null && ref !== void 0 ? ref : ""
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "mt-6 flex items-center",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_design_system__WEBPACK_IMPORTED_MODULE_1__/* .BodyText */ .Ac, {
                        size: "normal",
                        className: "text-dark-50",
                        children: "Raised Target"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_design_system__WEBPACK_IMPORTED_MODULE_1__/* .Icon */ .JO, {
                        className: "ml-2",
                        size: "text",
                        name: "InfoCircleOutlined"
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_design_system__WEBPACK_IMPORTED_MODULE_1__/* .BodyText */ .Ac, {
                size: "medium",
                semiBold: true,
                className: "mt-3 text-light-40",
                children: (ref1 = terms === null || terms === void 0 ? void 0 : terms.raiseTarget) !== null && ref1 !== void 0 ? ref1 : ""
            })
        ]
    }));
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;