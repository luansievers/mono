"use strict";
exports.id = 910;
exports.ids = [910];
exports.modules = {

/***/ 18:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "M": () => (/* binding */ formatFiat),
/* harmony export */   "dt": () => (/* binding */ cryptoToFloat),
/* harmony export */   "a9": () => (/* binding */ formatCrypto)
/* harmony export */ });
/* harmony import */ var ethers__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1982);
/* harmony import */ var ethers__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(ethers__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5801);
/* harmony import */ var _graphql_generated__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2190);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2461);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_utils__WEBPACK_IMPORTED_MODULE_3__]);
_utils__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




function formatFiat(fiatAmount, options) {
    const defaultOptions = {
        style: "currency",
        currency: fiatAmount.symbol
    };
    const formatter = new Intl.NumberFormat("en-US", {
        ...defaultOptions,
        ...options
    });
    return formatter.format(fiatAmount.amount);
}
// ethers commify() doesn't pad an amount to 2 decimal places, so it just looks weird for a currency. Use this instead
const decimalFormatter = new Intl.NumberFormat("en-US", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
});
function cryptoToFloat(cryptoAmount) {
    switch(cryptoAmount.token){
        case _graphql_generated__WEBPACK_IMPORTED_MODULE_2__/* .SupportedCrypto.Usdc */ .ww.Usdc:
            const usdcAsFloat = parseFloat(ethers__WEBPACK_IMPORTED_MODULE_0__.utils.formatUnits(cryptoAmount.amount, _constants__WEBPACK_IMPORTED_MODULE_1__/* .USDC_DECIMALS */ .p8));
            return usdcAsFloat;
        case _graphql_generated__WEBPACK_IMPORTED_MODULE_2__/* .SupportedCrypto.Gfi */ .ww.Gfi:
            const gfiAsFloat = parseFloat(ethers__WEBPACK_IMPORTED_MODULE_0__.utils.formatUnits(cryptoAmount.amount, _constants__WEBPACK_IMPORTED_MODULE_1__/* .GFI_DECIMALS */ .$O));
            return gfiAsFloat;
        case _graphql_generated__WEBPACK_IMPORTED_MODULE_2__/* .SupportedCrypto.Fidu */ .ww.Fidu:
            const fiduAsFloat = parseFloat(ethers__WEBPACK_IMPORTED_MODULE_0__.utils.formatUnits(cryptoAmount.amount, _constants__WEBPACK_IMPORTED_MODULE_1__/* .FIDU_DECIMALS */ .K4));
            return fiduAsFloat;
        case _graphql_generated__WEBPACK_IMPORTED_MODULE_2__/* .SupportedCrypto.CurveLp */ .ww.CurveLp:
            const curveLpAsFloat = parseFloat(ethers__WEBPACK_IMPORTED_MODULE_0__.utils.formatUnits(cryptoAmount.amount, _constants__WEBPACK_IMPORTED_MODULE_1__/* .CURVE_LP_DECIMALS */ .as));
            return curveLpAsFloat;
        default:
            (0,_utils__WEBPACK_IMPORTED_MODULE_3__/* .assertUnreachable */ .UT)(cryptoAmount.token);
    }
}
function formatCrypto(cryptoAmount, options) {
    const defaultOptions = {
        includeSymbol: true,
        includeToken: false
    };
    const { includeSymbol , includeToken  } = {
        ...defaultOptions,
        ...options
    };
    const float = cryptoToFloat(cryptoAmount);
    const amount = float > 0 && float < 0.01 ? "<0.01" : decimalFormatter.format(float);
    const prefix = cryptoAmount.token === _graphql_generated__WEBPACK_IMPORTED_MODULE_2__/* .SupportedCrypto.Usdc */ .ww.Usdc && includeSymbol ? "$" : "";
    const suffix = includeToken ? ` ${tokenMap[cryptoAmount.token]}` : "";
    return prefix.concat(amount).concat(suffix);
}
const tokenMap = {
    [_graphql_generated__WEBPACK_IMPORTED_MODULE_2__/* .SupportedCrypto.Usdc */ .ww.Usdc]: "USDC",
    [_graphql_generated__WEBPACK_IMPORTED_MODULE_2__/* .SupportedCrypto.Gfi */ .ww.Gfi]: "GFI",
    [_graphql_generated__WEBPACK_IMPORTED_MODULE_2__/* .SupportedCrypto.Fidu */ .ww.Fidu]: "FIDU",
    [_graphql_generated__WEBPACK_IMPORTED_MODULE_2__/* .SupportedCrypto.CurveLp */ .ww.CurveLp]: "FIDU-USDC-F"
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5910:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "dt": () => (/* reexport safe */ _currency_units__WEBPACK_IMPORTED_MODULE_1__.dt),
/* harmony export */   "a9": () => (/* reexport safe */ _currency_units__WEBPACK_IMPORTED_MODULE_1__.a9),
/* harmony export */   "M": () => (/* reexport safe */ _currency_units__WEBPACK_IMPORTED_MODULE_1__.M)
/* harmony export */ });
/* unused harmony export formatPercent */
/* harmony import */ var ethers__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1982);
/* harmony import */ var ethers__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(ethers__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _currency_units__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_currency_units__WEBPACK_IMPORTED_MODULE_1__]);
_currency_units__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

// Intl formatters are nice because they are sensitive to the user's device locale. For now they are hard-coded to en-US, but in the future this can be parameterized or even changed into hooks (to get locale from context)
const percentageFormatter = new Intl.NumberFormat("en-US", {
    style: "percent",
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
});
function formatPercent(n) {
    if (n instanceof FixedNumber) {
        return percentageFormatter.format(n.toUnsafeFloat());
    }
    return percentageFormatter.format(n);
}


__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;