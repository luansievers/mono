"use strict";
exports.id = 498;
exports.ids = [498];
exports.modules = {

/***/ 5498:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "A": () => (/* reexport safe */ _pool_card__WEBPACK_IMPORTED_MODULE_0__.A),
/* harmony export */   "f": () => (/* reexport safe */ _pending_pool_card__WEBPACK_IMPORTED_MODULE_1__.f)
/* harmony export */ });
/* harmony import */ var _pool_card__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2955);
/* harmony import */ var _pending_pool_card__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5093);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_pool_card__WEBPACK_IMPORTED_MODULE_0__, _pending_pool_card__WEBPACK_IMPORTED_MODULE_1__]);
([_pool_card__WEBPACK_IMPORTED_MODULE_0__, _pending_pool_card__WEBPACK_IMPORTED_MODULE_1__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);



__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2955:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "A": () => (/* binding */ PoolCard)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8103);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(clsx__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_design_system_progress__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7168);
/* harmony import */ var _lib_format__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5910);
/* harmony import */ var _lib_format_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1441);
/* harmony import */ var _lib_graphql_generated__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2190);
/* harmony import */ var _design_system__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1490);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_lib_format__WEBPACK_IMPORTED_MODULE_3__, _design_system__WEBPACK_IMPORTED_MODULE_5__]);
([_lib_format__WEBPACK_IMPORTED_MODULE_3__, _design_system__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);







function PoolCard({ image , artistName , poolName , totalSuppliedAmount , totalGoalAmount , type , className , onClick  }) {
    const totalSuppliedAmountFloat = (0,_lib_format__WEBPACK_IMPORTED_MODULE_3__/* .cryptoToFloat */ .dt)(totalSuppliedAmount);
    let supplied = "-";
    let progressPercentage = 0;
    if (!totalSuppliedAmount.amount.isZero()) {
        progressPercentage = totalSuppliedAmount.amount.toNumber() / totalGoalAmount.amount.toNumber() * 100;
        if (type != "failed") {
            supplied = (0,_lib_format__WEBPACK_IMPORTED_MODULE_3__/* .formatCrypto */ .a9)(totalSuppliedAmount);
        }
    }
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: clsx__WEBPACK_IMPORTED_MODULE_1___default()("flex gap-4 rounded-lg bg-green-100 px-6 py-4", onClick && "cursor-pointer", className),
        onClick: onClick,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "flex-none",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_design_system__WEBPACK_IMPORTED_MODULE_5__/* .Avatar */ .qE, {
                    size: 20,
                    image: image
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex-1 pt-[18.5px]",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_design_system__WEBPACK_IMPORTED_MODULE_5__/* .BodyText */ .Ac, {
                        size: "normal",
                        className: "text-light-40",
                        children: (artistName === null || artistName === void 0 ? void 0 : artistName.startsWith("0x")) ? (0,_lib_format_common__WEBPACK_IMPORTED_MODULE_6__/* .handleAddressFormat */ .p)(artistName) : artistName
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_design_system__WEBPACK_IMPORTED_MODULE_5__/* .Caption */ .YS, {
                        className: "pt-[3px] text-dark-50",
                        children: poolName
                    })
                ]
            }),
            type ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "flex-1 pt-[28px] text-center",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_design_system__WEBPACK_IMPORTED_MODULE_5__/* .BodyText */ .Ac, {
                            size: "normal",
                            className: "text-light-40",
                            children: supplied
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "flex-1 pt-[28px] text-center capitalize",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_design_system__WEBPACK_IMPORTED_MODULE_5__/* .Chip */ .Af, {
                            type: type,
                            children: type
                        })
                    })
                ]
            }) : undefined,
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "w-60 flex-none pt-[20px]",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_design_system_progress__WEBPACK_IMPORTED_MODULE_2__/* .Progress */ .E, {
                        percentage: progressPercentage,
                        type: type ? type : undefined
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "grid grid-cols-2 pt-[11px]",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_design_system__WEBPACK_IMPORTED_MODULE_5__/* .BodyText */ .Ac, {
                                size: "normal",
                                semiBold: true,
                                className: clsx__WEBPACK_IMPORTED_MODULE_1___default()("h-3 rounded-full", {
                                    "text-accent-2": !type,
                                    "text-light-40": type == "completed",
                                    "text-accent-3": type == "failed"
                                }),
                                children: (0,_lib_format__WEBPACK_IMPORTED_MODULE_3__/* .formatFiat */ .M)({
                                    symbol: _lib_graphql_generated__WEBPACK_IMPORTED_MODULE_4__/* .SupportedFiat.Usd */ .rQ.Usd,
                                    amount: totalSuppliedAmountFloat
                                })
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_design_system__WEBPACK_IMPORTED_MODULE_5__/* .BodyText */ .Ac, {
                                size: "normal",
                                className: "text-right text-dark-50",
                                children: [
                                    "of ",
                                    (0,_lib_format__WEBPACK_IMPORTED_MODULE_3__/* .formatCrypto */ .a9)(totalGoalAmount)
                                ]
                            })
                        ]
                    })
                ]
            })
        ]
    }));
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7168:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "E": () => (/* reexport */ Progress)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "clsx"
var external_clsx_ = __webpack_require__(8103);
var external_clsx_default = /*#__PURE__*/__webpack_require__.n(external_clsx_);
;// CONCATENATED MODULE: ./components/design-system/progress/progress.tsx


function Progress({ percentage , type , className  }) {
    return(/*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: external_clsx_default()("h-3 w-full rounded-full bg-green-90/70", className),
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: external_clsx_default()("h-3 rounded-full", {
                "bg-accent-2": !type,
                "bg-accent-2-opacity": type == "completed",
                "bg-accent-3-opacity": type == "failed"
            }),
            style: {
                width: `${percentage}%`
            }
        })
    }));
}

;// CONCATENATED MODULE: ./components/design-system/progress/index.tsx



/***/ })

};
;