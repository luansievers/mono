"use strict";
exports.id = 533;
exports.ids = [533];
exports.modules = {

/***/ 3533:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Kz": () => (/* binding */ createPool),
/* harmony export */   "gA": () => (/* binding */ updatePoolAddress),
/* harmony export */   "QV": () => (/* binding */ updatePoolBorrowerContractAddress),
/* harmony export */   "tb": () => (/* binding */ createBorrowerContract),
/* harmony export */   "dO": () => (/* binding */ mergeGraphAndMetaData),
/* harmony export */   "KQ": () => (/* binding */ lockJuniorCapital),
/* harmony export */   "Tk": () => (/* binding */ lockPool)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _lib_verify__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1945);
/* harmony import */ var _utilities_contract_util__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5060);



const JUNIOR_FEE_PERCENT = "20";
const INTEREST_APR = "50000000000000000"; // 5% APR
const PAYMENT_PERIOD_IN_DAYS = "10";
const TERM_IN_DAYS = "365";
const LATE_FEE_APR = "0";
const PRINCIPAL_GRACE_PERIOD_IN_DAYS = "185";
const FUNDABLE_AT = "0";
const ALLOWED_UID = [
    _lib_verify__WEBPACK_IMPORTED_MODULE_1__/* .UIDType.NonUSIndividual */ .DT.NonUSIndividual,
    _lib_verify__WEBPACK_IMPORTED_MODULE_1__/* .UIDType.NonUSEntity */ .DT.NonUSEntity,
    _lib_verify__WEBPACK_IMPORTED_MODULE_1__/* .UIDType.USEntity */ .DT.USEntity,
    _lib_verify__WEBPACK_IMPORTED_MODULE_1__/* .UIDType.USNonAccreditedIndividual */ .DT.USNonAccreditedIndividual,
    _lib_verify__WEBPACK_IMPORTED_MODULE_1__/* .UIDType.USAccreditedIndividual */ .DT.USAccreditedIndividual,
    _lib_verify__WEBPACK_IMPORTED_MODULE_1__/* .UIDType.isGoListed */ .DT.isGoListed, 
];
/**
 * @param goldfinchFactory - GoldfinchFactory contract
 * @param limit - string - limit of pool
 * @param borrowerContract - string - borrower contract address
 * @Promise void
 */ const createPool = async (goldfinchFactory, limit, borrowerContract)=>{
    var ref;
    const receipt = await ((ref = await (goldfinchFactory === null || goldfinchFactory === void 0 ? void 0 : goldfinchFactory.createPool(borrowerContract, JUNIOR_FEE_PERCENT, limit, INTEREST_APR, PAYMENT_PERIOD_IN_DAYS, TERM_IN_DAYS, LATE_FEE_APR, PRINCIPAL_GRACE_PERIOD_IN_DAYS, FUNDABLE_AT, ALLOWED_UID))) === null || ref === void 0 ? void 0 : ref.wait());
    return receipt;
};
/**
 * @param poolId - string - pool id
 * @param receipt - ContractReceipt - transaction receipt
 * @Promise void
 */ const updatePoolAddress = async (poolId, poolAddress)=>{
    return await axios__WEBPACK_IMPORTED_MODULE_0___default().patch(`/api/pool/${poolId}`, {
        poolAddress: poolAddress
    });
};
/**
 * @param poolId - poolId - pool id
 * @param borrowerContractAddress string - transaction receipt
 * @Promise ContractReceipt - transaction receipt of granting borrower privileges
 */ const updatePoolBorrowerContractAddress = async (poolId, borrowerContractAddress)=>{
    return (await axios__WEBPACK_IMPORTED_MODULE_0___default().patch(`/api/pool/${poolId}`, {
        borrowerContractAddress: borrowerContractAddress
    })).data;
};
/**
 * @param goldfinchFactory - GoldfinchFactory contract
 * @param account - address of account for which the borrower contract will be created for.
 * @Promise ContractReceipt - transaction receipt of granting borrower privileges
 */ const createBorrowerContract = async (goldfinchFactory, account)=>{
    const role = await goldfinchFactory.isBorrower();
    if (!role) {
        throw new Error("You are not an admin or borrower");
    }
    const borrowerContract = await (await goldfinchFactory.createBorrower(account)).wait();
    const lastEvent = (0,_utilities_contract_util__WEBPACK_IMPORTED_MODULE_2__/* .getLastEventArgs */ .w)(borrowerContract);
    return lastEvent.borrower;
};
const mergeGraphAndMetaData = (graphDatas, metaData)=>{
    return metaData.map((poolData)=>{
        const graphData = graphDatas.find((pool)=>pool.id == poolData.poolAddress
        );
        return {
            ...graphData,
            ...poolData
        };
    });
};
/**
 * Locks the Junior Capital of the Tranched Pool
 * @param borrowerFactory - Borrower contract
 * @param poolAddress - string - pool address
 * @Promise ContractReceipt - transaction receipt of locking junior capital
 */ const lockJuniorCapital = async (borrowerFactory, poolAddress)=>{
    const receipt = await (await (borrowerFactory === null || borrowerFactory === void 0 ? void 0 : borrowerFactory.lockJuniorCapital(poolAddress))).wait();
    return receipt;
};
/**
 * Locks the Tranched Pool so money can be withdrawn.
 * @param borrowerFactory - Borrower contract
 * @param poolAddress - string - pool address
 * @Promise ContractReceipt - transaction receipt of locking junior capital
 */ const lockPool = async (borrowerFactory, poolAddress)=>{
    const receipt = await (await (borrowerFactory === null || borrowerFactory === void 0 ? void 0 : borrowerFactory.lockPool(poolAddress))).wait();
    return receipt;
};


/***/ }),

/***/ 5060:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "w": () => (/* binding */ getLastEventArgs)
/* harmony export */ });
function getLastEventArgs(result) {
    const events = result.events;
    if (events) {
        const lastEvent = events[events.length - 1];
        if (lastEvent) {
            return lastEvent.args;
        }
    }
    return {};
}


/***/ })

};
;