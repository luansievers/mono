"use strict";
(() => {
var exports = {};
exports.id = 478;
exports.ids = [478];
exports.modules = {

/***/ 9114:
/***/ ((module) => {

module.exports = require("@apollo/client");

/***/ }),

/***/ 5360:
/***/ ((module) => {

module.exports = require("@next/env");

/***/ }),

/***/ 252:
/***/ ((module) => {

module.exports = require("next/dist/compiled/cookie");

/***/ }),

/***/ 9371:
/***/ ((module) => {

module.exports = require("next/dist/compiled/node-fetch");

/***/ }),

/***/ 600:
/***/ ((module) => {

module.exports = require("next/dist/server/accept-header.js");

/***/ }),

/***/ 730:
/***/ ((module) => {

module.exports = require("next/dist/server/api-utils/node.js");

/***/ }),

/***/ 5947:
/***/ ((module) => {

module.exports = require("next/dist/server/base-http/node.js");

/***/ }),

/***/ 562:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 2779:
/***/ ((module) => {

module.exports = require("next/dist/server/request-meta.js");

/***/ }),

/***/ 6724:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/constants.js");

/***/ }),

/***/ 3539:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/detect-domain-locale.js");

/***/ }),

/***/ 2374:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/detect-locale-cookie.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 5753:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-match.js");

/***/ }),

/***/ 9521:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/prepare-destination.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 9819:
/***/ ((module) => {

module.exports = require("querystring");

/***/ }),

/***/ 4269:
/***/ ((module) => {

module.exports = require("url");

/***/ }),

/***/ 3685:
/***/ ((module) => {

module.exports = require("http");

/***/ }),

/***/ 7979:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_dist_server_node_polyfill_fetch__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7157);
/* harmony import */ var next_dist_server_node_polyfill_fetch__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_node_polyfill_fetch__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2800);
/* harmony import */ var next_dist_build_webpack_loaders_next_serverless_loader_api_handler__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6249);

        
      const { processEnv } = __webpack_require__(5360)
      processEnv([{"path":".env.local","contents":"# Copy the contents of this file to your .env.local. It will serve as a good baseline to get the app running locally.\n\n# (mainnet | localhost | murmuration | aurora_testnet) this determines many things: which contract addresses to use, which metadata files to use, which chain ID to allow in the client, which graphQL url to use\nNEXT_PUBLIC_NETWORK_NAME=aurora_testnet\n\n# If you set this variable, you can override the graphQL url provided via NEXT_PUBLIC_NETWORK_NAME. Use this if you want to test your own private subgraph that indexes mainnet\n# NEXT_PUBLIC_GRAPHQL_URL=https://api.thegraph.com/subgraphs/name/pugbyte/goldfinch\n\n# Necessary to form a connection with WalletConnect, among other things. You can create your own by making a free account and project on Alchemy and copying the RPC URL.\nNEXT_PUBLIC_MAINNET_RPC_URL=https://eth-mainnet.alchemyapi.io/v2/0dpnzkbReb43heyUt-dTXH-5E6a6OED7\n\n# Firebase functions base URL (Optional) - These are normally determined by NEXT_PUBLIC_NETWORK_NAME, but you can override them here\nNEXT_PUBLIC_GCLOUD_FUNCTIONS_URL=\"https://us-central1-free-artists.cloudfunctions.net\"\n\n# Persona config (Optional) - These are normally determined by NEXT_PUBLIC_NETWORK_NAME, but you can override them here\n# NEXT_PUBLIC_PERSONA_TEMPLATE=\"\"\n# NEXT_PUBLIC_PERSONA_ENVIRONMENT=\"\"\n\n# WEAVIK\nDISCORD_WEBHOOK_URL=https://discord.com/api/webhooks/1029462015942598758/22HeMoWx7zNcd2EL1wIHwGotzkS9BLAq59oc35xrsrFm35_ERXb0jOLKBO39ICHSvDEq\n\n# Added for pool approval or other admin actions. Change it every build to be secure\nNEXT_PUBLIC_ADMIN_TOKEN_FOR_API='dummy-token'"}])
    
        
        const runtimeConfig = {}
        ;
        

        

        const combinedRewrites = Array.isArray(private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites */ .Dg)
          ? private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites */ .Dg
          : []

        if (!Array.isArray(private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites */ .Dg)) {
          combinedRewrites.push(...private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites.beforeFiles */ .Dg.beforeFiles)
          combinedRewrites.push(...private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites.afterFiles */ .Dg.afterFiles)
          combinedRewrites.push(...private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites.fallback */ .Dg.fallback)
        }

        const apiHandler = (0,next_dist_build_webpack_loaders_next_serverless_loader_api_handler__WEBPACK_IMPORTED_MODULE_2__/* .getApiHandler */ .Y)({
          pageModule: __webpack_require__(5395),
          rewrites: combinedRewrites,
          i18n: undefined,
          page: "/api/gfi-grants",
          basePath: "",
          pageIsDynamic: false,
          encodedPreviewProps: {previewModeId:"3ee4203cd0dd201d10b0a5487356e35d",previewModeSigningKey:"eb958fed8176dfe904b837b894e324a83bc39abfc4538547a88e8cae630e2114",previewModeEncryptionKey:"f96e00f4590ab6bdc87dc34adba894c2350cb50b496abdc239ba32bc6f2725be"}
        })
        /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (apiHandler);
      

/***/ }),

/***/ 5395:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ index_page)
});

;// CONCATENATED MODULE: external "fs"
const external_fs_namespaceObject = require("fs");
var external_fs_default = /*#__PURE__*/__webpack_require__.n(external_fs_namespaceObject);
;// CONCATENATED MODULE: external "path"
const external_path_namespaceObject = require("path");
var external_path_default = /*#__PURE__*/__webpack_require__.n(external_path_namespaceObject);
;// CONCATENATED MODULE: external "@sentry/nextjs"
const nextjs_namespaceObject = require("@sentry/nextjs");
// EXTERNAL MODULE: ./lib/graphql/generated.ts
var generated = __webpack_require__(2209);
;// CONCATENATED MODULE: ./pages/api/gfi-grants/index.page.ts




const fileToSource = {
    "./merkleDistributorInfo.json": generated/* IndirectGrantSource.MerkleDistributor */.eR.MerkleDistributor,
    "./merkleDistributorInfo.dev.json": generated/* IndirectGrantSource.MerkleDistributor */.eR.MerkleDistributor,
    "./backerMerkleDistributorInfo.json": generated/* IndirectGrantSource.BackerMerkleDistributor */.eR.BackerMerkleDistributor,
    "./backerMerkleDistributorInfo.dev.json": generated/* IndirectGrantSource.BackerMerkleDistributor */.eR.BackerMerkleDistributor,
    "./merkleDirectDistributorInfo.json": generated/* DirectGrantSource.MerkleDirectDistributor */.gq.MerkleDirectDistributor,
    "./merkleDirectDistributorInfo.dev.json": generated/* DirectGrantSource.MerkleDirectDistributor */.gq.MerkleDirectDistributor,
    "./backerMerkleDirectDistributorInfo.json": generated/* DirectGrantSource.BackerMerkleDirectDistributor */.gq.BackerMerkleDirectDistributor,
    "./backerMerkleDirectDistributorInfo.dev.json": generated/* DirectGrantSource.BackerMerkleDirectDistributor */.gq.BackerMerkleDirectDistributor
};
const merkleDistributorFiles =  false ? 0 : [
    "./merkleDistributorInfo.dev.json",
    "./backerMerkleDistributorInfo.dev.json", 
];
const merkleDirectDistributorFiles =  false ? 0 : [
    "./merkleDirectDistributorInfo.dev.json",
    "./backerMerkleDirectDistributorInfo.dev.json", 
];
const filesToSearch = merkleDistributorFiles.concat(merkleDirectDistributorFiles);
const fileData = filesToSearch.map((file)=>{
    const pathname = external_path_default().resolve(`${process.cwd()}/gfi-grants`, file);
    const grantManifest = JSON.parse(external_fs_default().readFileSync(pathname, "utf-8"));
    return {
        file,
        grantManifest
    };
});
function findMatchingGrants(account) {
    let allMatchingGrants = [];
    for (const { file , grantManifest  } of fileData){
        const matchingGrants = grantManifest.grants.filter((grant)=>grant.account.toLowerCase() === account.toLowerCase()
        );
        allMatchingGrants = allMatchingGrants.concat(matchingGrants.map((g)=>({
                source: fileToSource[file],
                ...g
            })
        ));
    }
    return allMatchingGrants;
}
const handler = async (req, res)=>{
    const account = req.query.account;
    if (!account) {
        res.status(500).json({
            message: "You must provide an 'account' parameter in the query string."
        });
        return;
    }
    try {
        const matchingGrants = findMatchingGrants(account);
        res.status(200).json({
            account,
            matchingGrants
        });
    } catch (e) {
        res.status(500).json({
            message: `Error searching grants: ${e.message}`
        });
    }
};
/* harmony default export */ const index_page = ((0,nextjs_namespaceObject.withSentry)(handler));


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [884,800,209], () => (__webpack_exec__(7979)));
module.exports = __webpack_exports__;

})();