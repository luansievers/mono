"use strict";
(() => {
var exports = {};
exports.id = 137;
exports.ids = [137];
exports.modules = {

/***/ 9114:
/***/ ((module) => {

module.exports = require("@apollo/client");

/***/ }),

/***/ 5360:
/***/ ((module) => {

module.exports = require("@next/env");

/***/ }),

/***/ 2167:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 252:
/***/ ((module) => {

module.exports = require("next/dist/compiled/cookie");

/***/ }),

/***/ 9371:
/***/ ((module) => {

module.exports = require("next/dist/compiled/node-fetch");

/***/ }),

/***/ 600:
/***/ ((module) => {

module.exports = require("next/dist/server/accept-header.js");

/***/ }),

/***/ 730:
/***/ ((module) => {

module.exports = require("next/dist/server/api-utils/node.js");

/***/ }),

/***/ 5947:
/***/ ((module) => {

module.exports = require("next/dist/server/base-http/node.js");

/***/ }),

/***/ 562:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 2779:
/***/ ((module) => {

module.exports = require("next/dist/server/request-meta.js");

/***/ }),

/***/ 6724:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/constants.js");

/***/ }),

/***/ 3539:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/detect-domain-locale.js");

/***/ }),

/***/ 2374:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/detect-locale-cookie.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 5753:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-match.js");

/***/ }),

/***/ 9521:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/prepare-destination.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 7104:
/***/ ((module) => {

module.exports = require("qs");

/***/ }),

/***/ 9819:
/***/ ((module) => {

module.exports = require("querystring");

/***/ }),

/***/ 4269:
/***/ ((module) => {

module.exports = require("url");

/***/ }),

/***/ 3685:
/***/ ((module) => {

module.exports = require("http");

/***/ }),

/***/ 8304:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_dist_server_node_polyfill_fetch__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7157);
/* harmony import */ var next_dist_server_node_polyfill_fetch__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_node_polyfill_fetch__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2800);
/* harmony import */ var next_dist_build_webpack_loaders_next_serverless_loader_api_handler__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6249);

        
      const { processEnv } = __webpack_require__(5360)
      processEnv([{"path":".env.local","contents":"# Copy the contents of this file to your .env.local. It will serve as a good baseline to get the app running locally.\n\n# (mainnet | localhost | murmuration | aurora_testnet) this determines many things: which contract addresses to use, which metadata files to use, which chain ID to allow in the client, which graphQL url to use\nNEXT_PUBLIC_NETWORK_NAME=aurora_testnet\n\n# If you set this variable, you can override the graphQL url provided via NEXT_PUBLIC_NETWORK_NAME. Use this if you want to test your own private subgraph that indexes mainnet\n# NEXT_PUBLIC_GRAPHQL_URL=https://api.thegraph.com/subgraphs/name/pugbyte/goldfinch\n\n# Necessary to form a connection with WalletConnect, among other things. You can create your own by making a free account and project on Alchemy and copying the RPC URL.\nNEXT_PUBLIC_MAINNET_RPC_URL=https://eth-mainnet.alchemyapi.io/v2/0dpnzkbReb43heyUt-dTXH-5E6a6OED7\n\n# Firebase functions base URL (Optional) - These are normally determined by NEXT_PUBLIC_NETWORK_NAME, but you can override them here\nNEXT_PUBLIC_GCLOUD_FUNCTIONS_URL=\"https://us-central1-free-artists.cloudfunctions.net\"\n\n# Persona config (Optional) - These are normally determined by NEXT_PUBLIC_NETWORK_NAME, but you can override them here\n# NEXT_PUBLIC_PERSONA_TEMPLATE=\"\"\n# NEXT_PUBLIC_PERSONA_ENVIRONMENT=\"\"\n\n# WEAVIK\nDISCORD_WEBHOOK_URL=https://discord.com/api/webhooks/1029462015942598758/22HeMoWx7zNcd2EL1wIHwGotzkS9BLAq59oc35xrsrFm35_ERXb0jOLKBO39ICHSvDEq\n\n# Added for pool approval or other admin actions. Change it every build to be secure\nNEXT_PUBLIC_ADMIN_TOKEN_FOR_API='dummy-token'"}])
    
        
        const runtimeConfig = {}
        ;
        

        

        const combinedRewrites = Array.isArray(private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites */ .Dg)
          ? private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites */ .Dg
          : []

        if (!Array.isArray(private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites */ .Dg)) {
          combinedRewrites.push(...private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites.beforeFiles */ .Dg.beforeFiles)
          combinedRewrites.push(...private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites.afterFiles */ .Dg.afterFiles)
          combinedRewrites.push(...private_dot_next_routes_manifest_json__WEBPACK_IMPORTED_MODULE_1__/* .rewrites.fallback */ .Dg.fallback)
        }

        const apiHandler = (0,next_dist_build_webpack_loaders_next_serverless_loader_api_handler__WEBPACK_IMPORTED_MODULE_2__/* .getApiHandler */ .Y)({
          pageModule: __webpack_require__(628),
          rewrites: combinedRewrites,
          i18n: undefined,
          page: "/api/pool/[poolId]",
          basePath: "",
          pageIsDynamic: true,
          encodedPreviewProps: {previewModeId:"3ee4203cd0dd201d10b0a5487356e35d",previewModeSigningKey:"eb958fed8176dfe904b837b894e324a83bc39abfc4538547a88e8cae630e2114",previewModeEncryptionKey:"f96e00f4590ab6bdc87dc34adba894c2350cb50b496abdc239ba32bc6f2725be"}
        })
        /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (apiHandler);
      

/***/ }),

/***/ 628:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _lib_graphql_generated__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2209);
/* harmony import */ var _index_page__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6672);



/**
 * This handler is used to get a pool by it's id and patch the pool with new data
 * TODO: Add necessary typings
 */ async function handler(req, res) {
    const { method  } = req;
    const { poolId  } = req.query;
    if (typeof poolId != "string") {
        res.status(405).end(`Method ${method} Not Allowed`);
        return;
    }
    switch(method){
        case "GET":
            {
                try {
                    //TODO: Cloud function can be modified to retrieve by id and thus unnecessary iteration can be avoided
                    const poolDataResponse = await axios__WEBPACK_IMPORTED_MODULE_0___default().get(_index_page__WEBPACK_IMPORTED_MODULE_2__.POOL_CLOUD_URL);
                    const fileData = poolDataResponse.data.find((data)=>data.id === poolId
                    );
                    res.status(200).json(fileData);
                } catch (error) {
                    console.error(error);
                    res.status(405).end(`Error occurred while fetching data`);
                }
                break;
            }
        case "PATCH":
            {
                const { poolAddress , status , token , borrowerContractAddress  } = req.body || {};
                const changes = {};
                if (!poolAddress && !status && !borrowerContractAddress) {
                    res.status(405).end(`Nothing to patch`);
                    return;
                }
                try {
                    changes.id = poolId;
                    if (poolAddress) {
                        changes.poolAddress = poolAddress;
                    }
                    if (borrowerContractAddress) {
                        changes.borrowerContract = borrowerContractAddress;
                    }
                    /**
         * Checks if status exist in the enum. Also verifies the token passed in by user
         */ if (status && Object.values(_lib_graphql_generated__WEBPACK_IMPORTED_MODULE_1__/* .Pool_Status_Type */ .k$).includes(status)) {
                        if (!token && token != ("dummy-token" || 0)) {
                            res.status(405).end(`Invalid token or token mismatch`);
                            return;
                        }
                        changes.status = status;
                    }
                    await axios__WEBPACK_IMPORTED_MODULE_0___default().post(_index_page__WEBPACK_IMPORTED_MODULE_2__.POOL_CLOUD_URL, {
                        poolData: {
                            id: changes.id,
                            data: changes
                        }
                    });
                    res.status(200).json({
                        message: "success"
                    });
                } catch (error) {
                    console.error(error);
                    res.status(405).end(`Error while saving data`);
                }
                break;
            }
        default:
            res.setHeader("Allow", [
                "GET",
                "PATCH"
            ]);
            res.status(405).end(`Method ${method} Not Allowed`);
    }
};


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [884,800,209,672], () => (__webpack_exec__(8304)));
module.exports = __webpack_exports__;

})();